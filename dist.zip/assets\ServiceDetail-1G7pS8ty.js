import{a as e}from"./rolldown-runtime-B0Z9INg1.js";import{A as t,B as n,Bt as r,C as i,D as a,E as o,F as s,G as ee,H as te,I as c,K as l,Kt as u,L as d,M as f,N as p,O as m,P as h,R as g,S as _,T as v,U as y,V as b,W as x,_ as S,a as C,an as w,b as T,c as E,cn as D,d as O,f as k,ft as A,g as j,h as M,i as N,j as P,k as F,l as I,m as L,n as ne,o as R,r as z,s as B,t as V,u as H,v as U,vt as W,w as G,x as K,y as q,z as J}from"./vendor-icons-CtcfWXJJ.js";import{l as Y}from"./vendor-router-DDaJwyRe.js";import{a as X,i as Z,o as re}from"./vendor-motion-CWLwb6Rs.js";import{l as Q}from"./index-D98ybU2M.js";import{t as ie}from"./CTA-v_eM4gyN.js";import{t as ae}from"./QuickContactSection-BfSzvLzu.js";var oe=e(D(),1),$=re(),se={"custom-software-development":{pill:`Custom Software Development`,heroTitle:`Custom Software Development for Growing Enterprises`,heroSubtitle:`Scalable software architecture, intelligent workflow automation, and custom enterprise tools engineered to power your business growth.`,tailoredTitle:`Tailored Software Solutions Designed Around Your Business`,tailoredDesc:`Every business has unique workflows, challenges, and goals. Off-the-shelf software often creates limitations that slow growth and reduce efficiency. At White Gravity, we develop custom software solutions that fit your business perfectly, helping you streamline operations, automate processes, and improve overall performance. From startups to enterprises, we deliver innovative software products that are secure, scalable, and built to support your future growth.`,tailoredImg:`/images/service-website.jpg`,subServicesTitle:`Our Custom Software Development Services`,subServices:[{icon:ee,title:`Enterprise Software Development`,desc:`Powerful business applications designed to manage operations, resources, and organizational workflows efficiently.`},{icon:y,title:`CRM & Customer Management Systems`,desc:`Centralize customer data, improve communication, and enhance customer experiences with customized CRM solutions.`},{icon:J,title:`Workflow Automation Solutions`,desc:`Reduce manual tasks and increase productivity through intelligent automation systems tailored to your processes.`},{icon:M,title:`SaaS Product Development`,desc:`Launch subscription-based software platforms with modern architecture and seamless user experiences.`},{icon:I,title:`Custom Dashboards & Reporting Tools`,desc:`Gain real-time insights through interactive dashboards and data-driven reporting systems.`},{icon:O,title:`Software Integration Services`,desc:`Connect your software ecosystem with third-party tools, APIs, payment gateways, and enterprise platforms.`}],faqsTitle:`Frequently Asked Questions — Custom Software Development in USA`,faqs:[{q:`What is custom software development?`,a:`Custom software development is the process of designing, building, deploying, and maintaining software tailored specifically for a specific set of users, functions, or organizations.`},{q:`Is custom software better than ready-made software?`,a:`Yes, custom software fits your exact business workflows, scales seamlessly with your growth, eliminates recurring license fees, and gives you 100% IP ownership.`},{q:`Can you upgrade existing software?`,a:`Yes, we modernize legacy codebases, refactor databases, migrate to cloud infrastructure, and add new features to existing software applications.`},{q:`How secure is custom software?`,a:`We build enterprise security by design, incorporating data encryption, role-based access control (RBAC), security audits, and OWASP compliance.`},{q:`Do you provide post-launch support?`,a:`Yes, we offer ongoing maintenance, server monitoring, bug fixes, feature enhancements, and dedicated SLA support packages.`}]},"website-development":{pill:`Website Development`,heroTitle:`Custom Website Design & Modern Web Development`,heroSubtitle:`High-converting, responsive websites engineered for ultra-fast performance, modern visual appeal, and superior search visibility.`,tailoredTitle:`Custom Website Development Services by White Gravity`,tailoredDesc:`Website development in USA is one of White Gravity's core specialties. We create modern, high-performing websites that do more than just look impressive—they help businesses grow. Every website is built with a focus on speed, responsive design, SEO best practices, and a seamless user experience across all devices.

Whether you need a business website, corporate portal, portfolio, landing page, eCommerce store, or a custom web solution, our experienced team delivers websites tailored to your goals. At White Gravity, we combine creative design with powerful development to build websites that strengthen your online presence and drive measurable business results.`,tailoredImg:`/images/service-website.jpg`,subServicesTitle:`Website Development Services We Offer`,subServices:[{icon:L,title:`Custom Website Design`,desc:`Unique, brand-aligned designs tailored to your business — no templates, no compromises.`},{icon:l,title:`WordPress Development`,desc:`Custom WordPress themes and plugins for content-rich, easy-to-manage business websites.`},{icon:f,title:`React & Next.js Sites`,desc:`Blazing-fast static and server-rendered sites using modern JavaScript frameworks.`},{icon:h,title:`SEO-First Architecture`,desc:`Every page built with on-page SEO best practices — meta tags, schema, speed, and structure.`},{icon:v,title:`Responsive Design`,desc:`Pixel-perfect layouts that look amazing on every device — desktop, tablet, and mobile.`},{icon:n,title:`Performance Optimization`,desc:`Core Web Vitals optimization — fast loading, smooth interactions, and visual stability.`}],faqsTitle:`Frequently Asked Questions — Website Development in USA`,faqs:[{q:`How long does it take to build a custom website?`,a:`Standard business websites take 2 to 4 weeks, while complex web applications take 4 to 8 weeks.`},{q:`Will my website be mobile-friendly & SEO optimized?`,a:`Yes! Every website we develop is 100% responsive across mobile, tablet, and desktop, and built with SEO best practices.`},{q:`Can I edit content on my website easily?`,a:`Yes, we provide easy-to-use CMS admin dashboards so your team can add or edit pages, blogs, and media anytime.`},{q:`Do you provide hosting and maintenance services?`,a:`Yes, we offer secure cloud hosting, SSL certificates, and ongoing maintenance packages to ensure your website remains fast, secure, and up-to-date.`}]},"ecommerce-development":{pill:`Ecommerce Development`,heroTitle:`Scalable E-Commerce Store Design & Development`,heroSubtitle:`High-performance Shopify, WooCommerce, and custom online storefronts built with seamless checkout, secure payments, and higher sales conversion.`,tailoredTitle:`Grow Your Online Business with Professional E-Commerce Solutions`,tailoredDesc:`ECommerce development in USA is one of White Gravity's core services. We build modern, secure, and scalable online stores that are designed to deliver exceptional user experiences and drive business growth.

Whether you're launching a new eCommerce brand or expanding an existing business, our team provides end-to-end development solutions. From custom storefront design and product catalog management to secure payment gateway integration, inventory management, order processing, and shipping solutions, we ensure every aspect of your online store is optimized for success.`,tailoredImg:`/images/service-ecommerce.jpg`,subServicesTitle:`ECommerce Development Services We Offer`,subServices:[{icon:d,title:`Shopify Development`,desc:`Custom Shopify stores with branded themes, apps, and optimized checkout flows.`},{icon:l,title:`WooCommerce Development`,desc:`Feature-rich WooCommerce stores for WordPress — flexible, scalable, and SEO-friendly.`},{icon:o,title:`Payment Gateway Integration`,desc:`Razorpay, Stripe, PayPal, Paytm, and secure custom payment gateways integration.`},{icon:z,title:`Inventory Management`,desc:`Real-time stock tracking, automated reordering, and multi-warehouse support.`},{icon:U,title:`Conversion Optimization`,desc:`A/B testing, checkout optimization, and analytics-driven improvements.`},{icon:te,title:`Shipping & Logistics`,desc:`Shipping API integration with Shiprocket, Delhivery, and custom logistics.`}],faqsTitle:`Frequently Asked Questions — ECommerce Development in USA`,faqs:[{q:`Which eCommerce platform should I choose for my business?`,a:`We recommend Shopify for fast turnkey setup and reliability, WooCommerce for custom WordPress flexibility, or headless custom Node/React for enterprise scale.`},{q:`Can you integrate Indian payment gateways and Shiprocket logistics?`,a:`Yes! We seamlessly integrate Razorpay, Paytm, Cashfree, Stripe, Shiprocket, Delhivery, and automated GST invoice plugins.`},{q:`Will my online store be secure and PCI-compliant?`,a:`Yes, all our ecommerce stores include SSL encryption, PCI-DSS compliant checkout flows, and DDoS protection.`},{q:`Do you provide mobile apps for ecommerce stores?`,a:`Yes, we develop companion iOS and Android mobile apps that sync seamlessly with your ecommerce store to provide a unified shopping experience.`}]},"mobile-app-development":{pill:`Mobile App Development`,heroTitle:`Next-Gen Mobile App Development for iOS & Android`,heroSubtitle:`Intuitive, feature-packed native and cross-platform mobile apps engineered with sleek UI/UX, rapid performance, and cloud scalability.`,tailoredTitle:`Expert Mobile App Development for iOS & Android Platforms`,tailoredDesc:`At White Gravity, we specialize in developing custom mobile applications that help businesses connect with customers, streamline operations, and accelerate digital growth. Our team creates high-performance Android and iOS apps with intuitive user experiences, modern designs, and scalable architectures tailored to your business objectives.

From strategy and UI/UX design to app development, API integration, testing, deployment, and ongoing maintenance, we provide end-to-end mobile app development services. Whether you need a customer-facing application, an enterprise mobility solution, an eCommerce app, or an on-demand service platform, we build secure, reliable, and feature-rich mobile applications that deliver exceptional performance across devices.`,tailoredImg:`/images/service-mobile.jpg`,subServicesTitle:`Mobile App Services We Offer`,subServices:[{icon:ne,title:`iOS App Development`,desc:`Native iOS apps with Swift — optimized for iPhone and iPad with Apple design guidelines.`},{icon:V,title:`Android App Development`,desc:`Native Android apps with Kotlin — optimized for the diverse Android device ecosystem.`},{icon:G,title:`Flutter Development`,desc:`Cross-platform apps with a single codebase — beautiful UI and near-native performance.`},{icon:f,title:`React Native Development`,desc:`Appointment booking, reservation systems, and scheduling platforms.`},{icon:m,title:`UI/UX Design`,desc:`User-centered design with wireframes, prototypes, and pixel-perfect interfaces.`},{icon:p,title:`App Store Optimization & Launch`,desc:`Complete App Store & Google Play submission, ASO optimization, and launch strategy.`}],faqsTitle:`Frequently Asked Questions — Mobile App Development in USA`,faqs:[{q:`Do you build native or cross-platform mobile apps?`,a:`We build both! We develop native Swift/Kotlin apps for maximum device integration, as well as Flutter and React Native cross-platform apps for cost-effective dual OS delivery.`},{q:`Will you submit my app to Apple App Store and Google Play?`,a:`Yes, we handle the entire App Store and Google Play submission, guidelines compliance, developer account setup, and store listing optimization.`},{q:`How do you ensure the app's security and data privacy?`,a:`We implement industry-standard encryption, secure API integrations, and robust authentication methods to protect user data and ensure compliance.`},{q:`What happens after the app is launched?`,a:`We offer comprehensive post-launch support, including bug fixes, performance monitoring, OS updates, and new feature development to keep your app competitive.`}]},"web-app-development":{pill:`Web App Development`,heroTitle:`Modern Web Applications & Enterprise SaaS Platforms`,heroSubtitle:`Scalable cloud applications, secure customer portals, and real-time interactive dashboards engineered for modern business operations.`,tailoredTitle:`Custom Web Application Development for Modern Enterprises`,tailoredDesc:`Web app development in USA is a key service at White Gravity, where we build custom web applications that help businesses streamline operations, improve productivity, and accelerate digital growth. Our solutions are designed with performance, security, and scalability in mind, ensuring they evolve alongside your business. Whether you need a custom CRM, ERP system, customer portal, SaaS platform, business dashboard, booking system, or workflow automation tool, our experienced developers deliver feature-rich applications tailored to your unique requirements. Using modern technologies and industry best practices, we create intuitive, reliable, and high-performing web applications that provide seamless user experiences across all devices.`,tailoredImg:`/images/service-webapp.jpg`,subServicesTitle:`Our Web Application Development Solutions`,subServices:[{icon:H,title:`SaaS Platforms`,desc:`Multi-tenant SaaS applications with subscription billing, user management, and analytics.`},{icon:E,title:`Admin Dashboards`,desc:`Real-time data dashboards with charts, filters, and role-based access control.`},{icon:C,title:`Enterprise Portals`,desc:`Internal portals for HR, operations, project management, and team collaboration.`},{icon:B,title:`Booking & Scheduling`,desc:`Appointment booking, reservation systems, and scheduling platforms.`},{icon:K,title:`LMS & E-Learning`,desc:`Learning management systems with courses, quizzes, certificates, and progress tracking.`},{icon:a,title:`API Development`,desc:`RESTful and GraphQL APIs for mobile apps, third-party integrations, and microservices.`}],faqsTitle:`Frequently Asked Questions — Web App Development in USA`,faqs:[{q:`What tech stack do you use for web application development?`,a:`We use React, Next.js, Node.js, Python, PHP/Laravel, PostgreSQL, MongoDB, and AWS cloud infrastructure.`},{q:`Can you build multi-tenant SaaS applications with subscription billing?`,a:`Yes! We build multi-tenant SaaS architectures with Stripe/Razorpay automated subscription billing, user roles, and admin management.`},{q:`How do you ensure data security in enterprise portals?`,a:`We implement SSL/TLS encryption, JWT authentication, Role-Based Access Control (RBAC), and regular vulnerability patching.`},{q:`Can you integrate the web application with our existing systems?`,a:`Absolutely. We specialize in API integrations and can connect your new web application seamlessly with your existing CRM, ERP, and third-party tools.`}]},"crm-erp-development":{pill:`CRM & ERP Development`,heroTitle:`Custom CRM & ERP Systems to Streamline Business Operations`,heroSubtitle:`Centralize your sales data, eliminate manual processes, and connect business workflows with bespoke CRM & ERP platforms.`,tailoredTitle:`Custom CRM & ERP Development Services by White Gravity`,tailoredDesc:`Managing customer relationships and business operations efficiently is essential for sustainable growth. At White Gravity, we develop powerful CRM and ERP solutions that help organizations centralize data, automate processes, and improve decision-making.

Our custom-built systems are designed to simplify daily operations, increase productivity, and provide complete visibility across departments. Whether you're a growing startup or an established enterprise, we deliver scalable solutions tailored to your unique business requirements.`,tailoredImg:`/images/service-crm.svg`,subServicesTitle:`Our CRM & ERP Development Solutions`,subServices:[{icon:x,title:`Custom CRM Software`,desc:`Manage leads, track sales pipelines, and improve customer retention with tailored CRM systems.`},{icon:N,title:`Enterprise Resource Planning (ERP)`,desc:`Integrate finance, HR, inventory, and operations into a single centralized ERP platform.`},{icon:O,title:`Zoho Customization`,desc:`Expert deployment, customization, and API integration for the Zoho One suite.`},{icon:R,title:`Sales & Marketing Automation`,desc:`Automate repetitive tasks, email campaigns, and follow-ups to empower your sales teams.`},{icon:P,title:`Workflow Integration`,desc:`Connect your CRM/ERP with third-party tools, payment gateways, and existing software.`},{icon:E,title:`Advanced Analytics & Reporting`,desc:`Gain real-time business insights with custom dashboards, forecasting, and data visualization.`}],faqsTitle:`Frequently Asked Questions — CRM & ERP Development`,faqs:[{q:`Should I choose a custom CRM or a ready-made solution like Zoho?`,a:`If your workflows are highly unique, a custom CRM is best. If you want fast deployment and standard features, customizing Zoho is more cost-effective.`},{q:`Can you migrate data from our old systems to the new ERP?`,a:`Yes! We securely migrate all your legacy data (customers, inventory, finance) to the new platform with zero data loss.`},{q:`Is training provided after deployment?`,a:`Absolutely. We provide comprehensive documentation and hands-on team training so your staff can efficiently use the new systems.`},{q:`How long does it take to deploy a custom ERP?`,a:`A standard CRM setup takes 2-4 weeks, while a comprehensive custom ERP implementation can take anywhere from 8 to 16 weeks depending on complexity.`}]},"digital-marketing":{pill:`Digital Marketing`,heroTitle:`Data-Driven Digital Marketing That Accelerates Growth`,heroSubtitle:`Targeted SEO, full-funnel content marketing, and performance social campaigns designed to drive qualified traffic and maximize conversions.`,tailoredTitle:`Results-Driven Digital Marketing Services by White Gravity`,tailoredDesc:`In today's competitive digital landscape, having a website is not enough. Businesses need a strategic digital marketing approach to reach the right audience, increase brand visibility, and generate consistent leads. At White Gravity, we create data-driven marketing campaigns that help businesses grow faster and achieve measurable results.

Our team combines creativity, technology, and analytics to develop customized marketing strategies that maximize your online presence and deliver long-term success.`,tailoredImg:`/images/service-marketing.jpg`,subServicesTitle:`Digital Marketing Services We Offer`,subServices:[{icon:s,title:`Search Engine Optimization (SEO)`,desc:`Improve your search engine rankings, increase organic traffic, and attract potential customers through effective SEO strategies.`},{icon:R,title:`Pay-Per-Click Advertising (PPC)`,desc:`Reach targeted audiences instantly with high-converting Google Ads and paid advertising campaigns.`},{icon:c,title:`Social Media Marketing`,desc:`Build brand awareness, engage your audience, and grow your presence across popular social media platforms.`},{icon:F,title:`Content Marketing`,desc:`Create valuable and engaging content that attracts, educates, and converts your target audience.`},{icon:j,title:`Email Marketing`,desc:`Nurture leads and strengthen customer relationships with personalized email campaigns.`},{icon:i,title:`Local SEO`,desc:`Enhance your visibility in local search results and attract customers from your target geographic area.`}],faqsTitle:`Frequently Asked Questions — Digital Marketing in USA`,faqs:[{q:`How soon can I expect results from SEO?`,a:`SEO is a compounding organic growth strategy. Initial ranking improvements typically appear within 60 to 90 days, with significant traffic growth by months 4 to 6.`},{q:`What platforms do you manage for Social Media Marketing?`,a:`We manage Meta (Instagram & Facebook), LinkedIn, YouTube, and Google Business Profile listing campaigns.`},{q:`Do you provide detailed monthly ROI reports?`,a:`Yes! You receive transparent monthly analytics reports detailing traffic, keyword rankings, cost-per-lead, and conversion performance.`},{q:`Do you create custom content for digital marketing campaigns?`,a:`Yes, our in-house team creates high-quality, engaging content including ad copies, blog posts, graphics, and videos tailored to your brand voice.`}]},"meta-google-ads":{pill:`Meta Ads & Google Ads`,heroTitle:`High-ROI Meta Ads & Google Ads Campaign Management`,heroSubtitle:`Reach high-intent customers, reduce acquisition costs, and maximize return on ad spend with precision-targeted PPC and paid social advertising.`,tailoredTitle:`Performance-Driven Meta Ads & Google Ads Management`,tailoredDesc:`Online advertising is one of the fastest ways to attract potential customers and grow your business. At White Gravity, we create and manage high-performing Meta Ads and Google Ads campaigns that help businesses increase visibility, generate qualified leads, and achieve measurable results.

Our advertising experts use advanced targeting, audience insights, and continuous optimization strategies to ensure every advertising dollar delivers maximum value.`,tailoredImg:`/images/service-ads.jpg`,subServicesTitle:`Advertising Services We Offer`,subServices:[{icon:q,title:`Google Search Ads`,desc:`Appear at the top of Google search results and capture customers actively searching for your products or services.`},{icon:T,title:`Google Display Ads`,desc:`Increase brand awareness and reach potential customers across millions of websites and apps.`},{icon:g,title:`Google Shopping Ads`,desc:`Showcase your products directly in Google search results and drive high-intent ecommerce traffic.`},{icon:S,title:`Meta Facebook Ads`,desc:`Connect with your target audience through engaging Facebook advertising campaigns designed to increase conversions.`},{icon:_,title:`Instagram Ads`,desc:`Promote your brand, products, and services with visually compelling Instagram advertising strategies.`},{icon:k,title:`Remarketing Campaigns`,desc:`Reconnect with previous website visitors and encourage them to complete their purchase or inquiry.`}],faqsTitle:`Frequently Asked Questions — Meta & Google Ads in USA`,faqs:[{q:`Which ad platform is better: Google Ads or Meta Ads?`,a:`Google Ads targets high-intent searchers actively looking to buy now, while Meta Ads (Facebook & Instagram) builds audience demand, interest, and retargeting. We often run both together for maximum performance.`},{q:`What budget is needed to start running ad campaigns?`,a:`We design flexible campaign budgets starting from $500/month up to enterprise scaling budgets.`},{q:`How do you optimize cost-per-lead (CPL) and ROAS?`,a:`We conduct A/B ad creative testing, conversion API tracking, negative keyword filtering, and weekly bid optimization.`},{q:`Will I have ownership of my ad accounts?`,a:`Yes, you retain 100% ownership and administrative access to all your advertising accounts, ensuring complete transparency and control.`}]},"zoho-consultation":{pill:`Zoho Consultation`,heroTitle:`Certified Zoho Consultation, Setup & System Integration`,heroSubtitle:`Maximize business efficiency with complete Zoho One setup, tailored workflow automations, and custom module integrations.`,tailoredTitle:`Certified Zoho Consultation & Development Services by White Gravity`,tailoredDesc:`Managing separate tools for CRM, finance, HR, and customer support leads to fragmented data and operational bottlenecks. At White Gravity, we provide end-to-end Zoho consultation, customization, and deployment to help your business operate as one unified digital ecosystem.

From Zoho CRM and Zoho Books to Zoho Desk, Zoho People, and complete Zoho One suites, our certified experts customize workflows, automate lead scoring, and train your team for maximum productivity.`,tailoredImg:`/images/service-zoho.jpg`,subServicesTitle:`Zoho Consultation Services We Offer`,subServices:[{icon:x,title:`Zoho CRM Customization`,desc:`Custom lead pipelines, automation rules, blueprint workflows, and sales dashboards.`},{icon:C,title:`Zoho One Setup & Migration`,desc:`Unified setup of 45+ integrated Zoho business apps tailored to your company operations.`},{icon:o,title:`Zoho Books & Finance Integration`,desc:`GST-compliant invoicing, automated bank reconciliation, and accounting setup.`},{icon:j,title:`Zoho Desk & Support Portals`,desc:`Omnichannel customer support ticketing, SLA automation, and self-service portals.`},{icon:N,title:`Zoho People & HRMS Integration`,desc:`Employee onboarding, attendance tracking, leave management, and performance appraisal.`},{icon:t,title:`Zoho API & Deluge Scripting`,desc:`Custom integrations between Zoho apps and third-party software using Deluge & REST APIs.`}],faqsTitle:`Frequently Asked Questions — Zoho Consultation in USA`,faqs:[{q:`Why choose White Gravity as your Zoho Partner in USA?`,a:`Our certified Zoho experts bring years of domain experience across CRM, ERP, and Zoho One apps to ensure smooth deployment and maximum ROI.`},{q:`Can you migrate data from Salesforce or Excel to Zoho CRM?`,a:`Yes! We handle full data migration from Salesforce, HubSpot, Excel, or custom databases into Zoho CRM with zero data loss.`},{q:`Do you offer custom Deluge scripting and third-party API integration?`,a:`Yes, our developers write custom Deluge scripts to connect Zoho with WhatsApp, payment gateways, e-commerce, and custom ERPs.`},{q:`Do you provide training for my team on how to use Zoho?`,a:`Yes, we offer comprehensive training sessions, customized user manuals, and ongoing support to ensure your team maximizes the potential of your Zoho applications.`}]}},ce=e=>({pill:e.title.toUpperCase(),heroSubtitle:`Build Smarter Business Solutions with ${e.title}`,tailoredTitle:`Tailored ${e.title} Designed Around Your Business`,tailoredDesc:`Every business has unique workflows, challenges, and goals. At White Gravity, we develop ${e.title} solutions that fit your business perfectly, helping you streamline operations, automate processes, and achieve measurable growth.`,tailoredImg:e.img||`/images/service-custom-software.jpg`,subServicesTitle:`Our ${e.title} Services`,subServices:[{icon:C,title:`Enterprise Solutions`,desc:`Scalable business applications designed to manage operations and organizational workflows.`},{icon:x,title:`Consultation & Strategy`,desc:`Strategic technology advisory and roadmaps tailored to your industry goals.`},{icon:P,title:`Process Automation`,desc:`Reduce manual tasks and increase productivity through intelligent automation systems.`},{icon:b,title:`Custom Implementation`,desc:`Tailored platforms engineered with modern architecture and seamless UX.`},{icon:E,title:`Analytics & Dashboards`,desc:`Real-time business insights through interactive dashboards and reporting systems.`},{icon:t,title:`API & Integration Services`,desc:`Connect your software ecosystem with third-party tools, payment gateways, and platforms.`}],faqsTitle:`Frequently Asked Questions — ${e.title} in USA`,faqs:[{q:`What is included in ${e.title}?`,a:`We provide end-to-end services from requirement discovery, architecture design, development, testing, to cloud deployment and ongoing maintenance.`},{q:`How do we get started with White Gravity?`,a:`Simply book a free 30-minute discovery call. Our tech leads will analyze your requirements and send a detailed proposal within 24 hours.`},{q:`Do you provide post-launch support?`,a:`Yes, we provide complimentary post-launch support and SLA-backed maintenance packages.`},{q:`Do you offer customized pricing packages?`,a:`Yes, we provide flexible and transparent pricing models tailored to your specific project requirements, ensuring you get the best value for your investment.`}]}),le=()=>(0,$.jsx)(`svg`,{width:`0`,height:`0`,className:`absolute`,"aria-hidden":`true`,children:(0,$.jsxs)(`defs`,{children:[(0,$.jsxs)(`linearGradient`,{id:`grad-instagram`,x1:`0%`,y1:`100%`,x2:`100%`,y2:`0%`,children:[(0,$.jsx)(`stop`,{offset:`0%`,stopColor:`#FCAF45`}),(0,$.jsx)(`stop`,{offset:`50%`,stopColor:`#FD1D1D`}),(0,$.jsx)(`stop`,{offset:`100%`,stopColor:`#E1306C`})]}),(0,$.jsxs)(`linearGradient`,{id:`grad-google`,x1:`0%`,y1:`0%`,x2:`100%`,y2:`100%`,children:[(0,$.jsx)(`stop`,{offset:`0%`,stopColor:`#4285F4`}),(0,$.jsx)(`stop`,{offset:`33%`,stopColor:`#34A853`}),(0,$.jsx)(`stop`,{offset:`66%`,stopColor:`#FBBC05`}),(0,$.jsx)(`stop`,{offset:`100%`,stopColor:`#EA4335`})]}),(0,$.jsxs)(`linearGradient`,{id:`grad-gmail`,x1:`0%`,y1:`0%`,x2:`100%`,y2:`100%`,children:[(0,$.jsx)(`stop`,{offset:`0%`,stopColor:`#EA4335`}),(0,$.jsx)(`stop`,{offset:`50%`,stopColor:`#FBBC05`}),(0,$.jsx)(`stop`,{offset:`100%`,stopColor:`#34A853`})]}),(0,$.jsxs)(`linearGradient`,{id:`grad-theme`,x1:`0%`,y1:`0%`,x2:`100%`,y2:`100%`,children:[(0,$.jsx)(`stop`,{offset:`0%`,stopColor:`#009B6C`}),(0,$.jsx)(`stop`,{offset:`100%`,stopColor:`#026f4f`})]})]})}),ue=e=>{let t=e.toLowerCase();return t.includes(`facebook`)?`#1877F2`:t.includes(`meta`)?`#0468FF`:t.includes(`instagram`)?`url(#grad-instagram)`:t.includes(`whatsapp`)?`#25D366`:t.includes(`linkedin`)?`#0A66C2`:t.includes(`youtube`)?`#FF0000`:t.includes(`twitter`)||t.match(/\bx\b/)?`#000000`:t.includes(`gmail`)?`url(#grad-gmail)`:t.includes(`google`)?`url(#grad-google)`:t.includes(`telegram`)?`#26A5E4`:t.includes(`github`)?`#181717`:t.includes(`apple`)||t.includes(`ios`)?`#000000`:t.includes(`android`)?`#3DDC84`:t.includes(`shopify`)?`#96bf48`:t.includes(`wordpress`)?`#21759b`:`url(#grad-theme)`};function de(){let{slug:e}=Y(),t=Q.find(t=>t.slug===e)||Q[0],n=se[t.slug]||ce(t),[i,a]=(0,oe.useState)(0);return(0,$.jsxs)($.Fragment,{children:[(0,$.jsx)(le,{}),(0,$.jsxs)(`section`,{className:`
          relative
          overflow-hidden
          bg-[#009B6C]
          text-white
          pt-20
          pb-10
          lg:pt-24
          lg:pb-14
          text-center
        `,children:[(0,$.jsx)(`div`,{className:`
            absolute
            inset-0
            opacity-20
            pointer-events-none
          `,style:{backgroundImage:`radial-gradient(circle at 20% 20%, rgba(255,255,255,.3) 0, transparent 40%), radial-gradient(circle at 80% 60%, rgba(255,255,255,.2) 0, transparent 40%)`}}),(0,$.jsxs)(`div`,{className:`
            container-x
            relative
            z-10
            flex
            flex-col
            items-center
            justify-center
            max-w-4xl
            mx-auto
          `,children:[(0,$.jsxs)(Z.div,{initial:{opacity:0,y:-15},animate:{opacity:1,y:0},className:`
              inline-flex
              items-center
              gap-2
              bg-white
              text-[#009B6C]
              px-4
              py-1.5
              rounded-full
              text-xs
              font-bold
              tracking-wider
              uppercase
              shadow-sm
              mb-4
            `,children:[(0,$.jsx)(r,{className:`w-3.5 h-3.5 stroke-[2.5]`}),n.pill]}),(0,$.jsx)(Z.h1,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.1},className:`text-2xl sm:text-3xl md:text-4xl lg:text-[44px] font-extrabold tracking-tight text-white leading-tight md:leading-[1.2] max-w-3xl mx-auto`,children:n.heroTitle||t.title}),(0,$.jsx)(Z.p,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:0},className:`mt-4 text-white/95 text-base sm:text-lg md:text-xl font-normal max-w-2xl mx-auto leading-relaxed`,children:n.heroSubtitle})]})]}),(0,$.jsx)(`section`,{className:`py-10 md:py-12 bg-white`,children:(0,$.jsxs)(`div`,{className:`
            container-x
            grid
            lg:grid-cols-12
            gap-12
            lg:gap-16
            items-center
          `,children:[(0,$.jsxs)(Z.div,{initial:{opacity:0,x:-30},whileInView:{opacity:1,x:0},viewport:{once:!0},transition:{duration:.3},className:`
              lg:col-span-6
              flex
              flex-col
              items-start
              text-left
            `,children:[(0,$.jsx)(`h2`,{className:`text-2xl sm:text-3xl md:text-4xl lg:text-[40px] font-extrabold text-slate-900 leading-tight tracking-tight`,children:n.tailoredTitle}),(0,$.jsx)(`p`,{className:`mt-5 text-slate-600 leading-relaxed text-base sm:text-lg md:text-[18px] whitespace-pre-line`,children:n.tailoredDesc}),(0,$.jsx)(`div`,{className:`block lg:hidden w-full mt-10 rounded-[2.5rem] overflow-hidden shadow-2xl border-4 md:border-8 border-white group relative bg-white p-3`,children:(0,$.jsx)(`img`,{src:n.tailoredImg,alt:t.title,className:`w-full h-auto max-h-[500px] object-contain group-hover:scale-105 transition-transform duration-700 rounded-2xl`})}),(0,$.jsx)(`div`,{className:`mt-8 space-y-4`,children:[`Scalable, enterprise-ready software architecture`,`Custom UI/UX & interactive prototype design`,`100% source code ownership & transparent sprints`,`3 months post-launch support & SLA maintenance`].map(e=>(0,$.jsxs)(`div`,{className:`
                    flex
                    items-center
                    gap-3.5
                  `,children:[(0,$.jsx)(u,{className:`
                      w-5
                      h-5
                      sm:w-6
                      sm:h-6
                      text-[#009B6C]
                      shrink-0
                    `}),(0,$.jsx)(`span`,{className:`
                      text-slate-800
                      font-semibold
                      text-base
                      sm:text-lg
                    `,children:e})]},e))}),(0,$.jsx)(`div`,{className:`mt-10`,children:(0,$.jsxs)(`a`,{href:`#contact-form-section`,className:`
                  inline-flex
                  items-center
                  gap-2
                  px-8
                  py-4
                  rounded-full
                  font-extrabold
                  bg-white
                  text-[#009B6C]
                  border-2
                  border-[#009B6C]
                  shadow-lg
                  hover:scale-105
                  transition-all
                `,children:[`Get Started Now`,(0,$.jsx)(w,{className:`w-5 h-5`})]})})]}),(0,$.jsx)(Z.div,{initial:{opacity:0,x:30},whileInView:{opacity:1,x:0},viewport:{once:!0},transition:{duration:.3},className:`
              hidden
              lg:block
              lg:col-span-6
              relative
            `,children:(0,$.jsx)(`div`,{className:`
                rounded-[2.5rem]
                overflow-hidden
                shadow-2xl
                border-4
                md:border-8
                border-white
                group
                relative
                bg-white
                flex
                items-center
                justify-center
                p-3
              `,children:(0,$.jsx)(`img`,{src:n.tailoredImg,alt:t.title,className:`
                  w-full
                  h-auto
                  max-h-[500px]
                  object-contain
                  group-hover:scale-105
                  transition-transform
                  duration-700
                  rounded-2xl
                `})})})]})}),(0,$.jsx)(ae,{defaultService:n.pill||`Website Development`,title:`Get a Free Proposal for ${n.pill||`Your Project`}`,subtitle:`Tell us your project requirements. Our senior engineering team will provide a comprehensive scope, timeline, and free consultation within 24 hours.`}),(0,$.jsx)(`section`,{className:`py-10 md:py-12 bg-[#e6f7f2]/50`,children:(0,$.jsxs)(`div`,{className:`container-x`,children:[(0,$.jsx)(`div`,{className:`text-center max-w-3xl mx-auto mb-14`,children:(0,$.jsx)(`h2`,{className:`
                text-2xl
                sm:text-3xl
                md:text-4xl
                font-bold
                text-[#009B6C]
                leading-tight
              `,children:n.subServicesTitle})}),(0,$.jsx)(`div`,{className:`
              grid
              grid-cols-1
              md:grid-cols-2
              lg:grid-cols-3
              gap-5
              md:gap-6
            `,children:n.subServices.map((e,t)=>{let n=e.icon;return(0,$.jsxs)(Z.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.4,delay:t*.06},className:`
                      service-detail-card

                      bg-white
                      rounded-2xl

                      p-5
                      sm:p-6

                      min-h-[220px]

                      shadow-sm
                      border
                      border-slate-200/80

                      hover:shadow-md
                      hover:border-[#009B6C]/50
                      hover:-translate-y-0.5

                      transition-all
                      duration-300

                      flex
                      flex-col

                      !items-center
                      !text-center
                    `,style:{alignItems:`center`,textAlign:`center`},children:[(0,$.jsx)(`div`,{className:`
                        service-card-icon

                        w-12
                        h-12

                        rounded-xl

                        bg-[#e6f7f2]

                        border
                        border-[#009B6C]/25

                        flex
                        items-center
                        justify-center

                        mb-4

                        shadow-xs

                        shrink-0

                        mx-auto
                      `,style:{display:`flex`,alignItems:`center`,justifyContent:`center`,marginLeft:`auto`,marginRight:`auto`},children:(0,$.jsx)(n,{className:`
                          !w-6
                          !h-6
                        `,style:{width:`24px`,height:`24px`,display:`block`,marginLeft:`auto`,marginRight:`auto`,fill:ue(e.title)}})}),(0,$.jsx)(`h3`,{className:`
                        service-card-title

                        !w-full
                        !max-w-full

                        !text-center

                        text-base
                        sm:text-lg
                        font-bold
                        text-slate-800

                        leading-snug

                        mx-auto
                      `,style:{width:`100%`,textAlign:`center`,marginLeft:`auto`,marginRight:`auto`},children:e.title}),(0,$.jsx)(`p`,{className:`
                        service-card-description

                        !w-full
                        !max-w-full

                        !text-center

                        mt-2

                        text-slate-600

                        leading-relaxed

                        text-xs
                        sm:text-sm

                        flex-grow

                        mx-auto
                      `,style:{width:`100%`,textAlign:`center`,marginLeft:`auto`,marginRight:`auto`},children:e.desc})]},e.title)})})]})}),(0,$.jsx)(`section`,{className:`py-10 md:py-12 bg-[#e6f7f2]/50`,children:(0,$.jsxs)(`div`,{className:`container-x`,children:[(0,$.jsx)(`div`,{className:`
              text-center
              max-w-4xl
              mx-auto
              mb-8
            `,children:(0,$.jsx)(`h2`,{className:`
                text-3xl
                sm:text-4xl
                md:text-5xl
                font-extrabold
                text-[#009B6C]
                leading-tight
              `,children:n.faqsTitle})}),(0,$.jsx)(`div`,{className:`
              max-w-4xl
              mx-auto
              bg-white
              rounded-3xl
              p-6
              sm:p-10
              shadow-sm
              border
              border-[#009B6C]/20
            `,children:(0,$.jsx)(`div`,{className:`divide-y divide-slate-100`,children:n.faqs.map((e,t)=>(0,$.jsxs)(`div`,{className:`
                      py-4
                      first:pt-0
                      last:pb-0
                    `,children:[(0,$.jsxs)(`button`,{onClick:()=>a(i===t?null:t),className:`
                        w-full
                        flex
                        items-center
                        justify-between
                        py-2
                        text-left
                        font-bold
                        text-slate-800
                        hover:text-[#009B6C]
                        transition-colors
                        gap-4
                      `,children:[(0,$.jsx)(`span`,{className:`
                          text-base
                          sm:text-lg
                          font-bold
                          text-slate-900
                        `,children:e.q}),(0,$.jsx)(`div`,{className:`
                          w-8
                          h-8
                          rounded-full
                          bg-slate-50
                          flex
                          items-center
                          justify-center
                          shrink-0
                        `,children:i===t?(0,$.jsx)(W,{className:`
                              w-4
                              h-4
                              text-[#009B6C]
                            `}):(0,$.jsx)(A,{className:`
                              w-4
                              h-4
                              text-[#009B6C]
                            `})})]}),(0,$.jsx)(X,{children:i===t&&(0,$.jsx)(Z.div,{initial:{height:0,opacity:0},animate:{height:`auto`,opacity:1},exit:{height:0,opacity:0},transition:{duration:.3},className:`
                            pt-2
                            pb-4
                            text-slate-600
                            text-sm
                            md:text-base
                            leading-relaxed
                          `,children:e.a})})]},e.q))})})]})}),(0,$.jsx)(ie,{})]})}export{de as default};