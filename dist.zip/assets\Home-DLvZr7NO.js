import{a as e}from"./rolldown-runtime-B0Z9INg1.js";import{At as t,Jt as n,Kt as r,Mt as i,X as a,Xt as o,Y as s,Z as c,_t as l,dn as u,en as d,kt as f,ln as p,mn as m,mt as h,q as g,rt as _,yt as v}from"./vendor-icons-M2GDecnN.js";import{c as y,n as b}from"./vendor-router-CLHTRlJU.js";import{a as x,i as S,o as C,t as w}from"./vendor-motion-C96MbW2l.js";import{a as T,i as E,l as D,r as O,s as k}from"./index-CXGb3iMJ.js";import{t as A}from"./SectionPill-D9-H5x28.js";import{t as j}from"./AnimatedText-BTs1GoC7.js";import{n as M,r as N,t as P}from"./TechStack-CgJS2MPu.js";import{t as F}from"./CTA-C-xJAfGz.js";import{t as I}from"./Projects-CPIVSF9r.js";var L=e(m(),1),R=C(),z=D.slice(0,4),B=D.slice(4,8),ee={hidden:{},visible:{transition:{staggerChildren:.07,delayChildren:.05}}},V={hidden:{opacity:0,y:24},visible:{opacity:1,y:0,transition:{duration:.45,ease:[.22,1,.36,1]}}};function H(){let e=y();return(0,R.jsxs)(`section`,{className:`relative overflow-hidden hero-animated-bg text-white min-h-0 lg:min-h-[65vh] flex items-center pt-24 sm:pt-28 lg:pt-20 pb-6 sm:pb-10 lg:pb-12`,children:[(0,R.jsx)(`div`,{className:`absolute inset-0 opacity-20 pointer-events-none`,style:{backgroundImage:`radial-gradient(circle at 20% 20%, rgba(255,255,255,.3) 0, transparent 40%), radial-gradient(circle at 80% 60%, rgba(255,255,255,.2) 0, transparent 40%)`}}),(0,R.jsx)(`div`,{className:`absolute top-0 right-0 -mt-16 -mr-16 sm:-mt-20 sm:-mr-20 w-48 h-48 sm:w-64 sm:h-64 bg-white opacity-10 rounded-full blur-3xl pointer-events-none`}),(0,R.jsx)(`div`,{className:`absolute bottom-0 left-0 -mb-10 -ml-16 sm:-mb-12 sm:-ml-20 w-60 h-60 sm:w-80 sm:h-80 bg-white opacity-10 rounded-full blur-3xl pointer-events-none`}),(0,R.jsx)(`div`,{className:`absolute inset-0 bg-[url('/images/noise.svg')] opacity-20 pointer-events-none mix-blend-overlay`}),(0,R.jsxs)(`div`,{className:`container-x relative z-10 w-full grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-center py-4 sm:py-6 lg:py-0`,children:[(0,R.jsxs)(S.div,{variants:ee,initial:`hidden`,animate:`visible`,className:`lg:col-span-7 col-span-full w-full flex flex-col items-center lg:items-start text-center lg:text-left pt-4 sm:pt-6 lg:pt-16 pb-0 sm:pb-2 lg:pb-10`,children:[(0,R.jsx)(S.span,{variants:V,className:`inline-flex items-center gap-1.5 sm:gap-2 bg-[#009B6C] border sm:border-2 border-white text-white px-3 sm:px-5 py-1.5 sm:py-2 rounded-full text-[11px] sm:text-sm font-bold shadow-lg max-w-full`,children:(0,R.jsx)(`span`,{className:`truncate`,children:O.tagline})}),(0,R.jsxs)(S.h1,{variants:V,className:`mt-4 sm:mt-5 text-[30px] xs:text-[32px] sm:text-4xl md:text-5xl lg:text-5xl xl:text-6xl font-bold leading-[1.08] tracking-tight text-white max-w-full`,children:[(0,R.jsx)(j,{text:`Transform Your`}),(0,R.jsx)(`br`,{}),(0,R.jsx)(j,{text:`Business with`}),(0,R.jsx)(`br`,{}),(0,R.jsx)(`span`,{className:`min-h-[1.2em] block break-words`,children:(0,R.jsx)(N,{words:[`Intelligent Technology`],textClass:`bg-clip-text text-transparent bg-gradient-to-r from-emerald-100 via-white to-teal-100`,cursorClass:`bg-emerald-300`})})]}),(0,R.jsx)(S.p,{variants:V,className:`mt-4 sm:mt-5 text-white/90 text-xs sm:text-sm md:text-base leading-relaxed max-w-2xl font-light pr-0 lg:pr-6`,children:`White Gravity Web Solutions delivers custom Website development & Mobile App development, custom CRM Development, E-Commerce, Zoho and business automation solutions for businesses across the USA.`}),(0,R.jsxs)(S.div,{variants:V,className:`hidden lg:flex mt-6 sm:mt-8 flex-col xs:flex-row sm:flex-row items-stretch xs:items-center sm:items-center gap-3 sm:gap-4 w-full xs:w-auto`,children:[(0,R.jsxs)(`a`,{href:`https://wa.me/14694614710?text=Hello%20White%20Gravity%2C%20I%20would%20like%20to%20book%20consultation`,target:`_blank`,rel:`noopener noreferrer`,"data-tracking":`whatsapp`,"data-action":`whatsapp_click`,onClick:()=>{window.dataLayer&&window.dataLayer.push({event:`whatsapp_click`,click_location:`hero_section`,whatsapp_number:`14694614710`})},className:`group relative inline-flex items-center justify-center gap-2 sm:gap-3 px-5 sm:px-6 py-3 rounded-full font-extrabold bg-[#F97316] text-white overflow-hidden transition-all hover:scale-105 shadow-[0_10px_30px_-5px_rgba(0,0,0,0.3)] hover:shadow-[0_15px_40px_-5px_rgba(255,255,255,0.4)] text-xs sm:text-sm md:text-base w-full xs:w-auto`,children:[(0,R.jsx)(`span`,{className:`relative z-10`,children:`Book Free Consultation`}),(0,R.jsx)(u,{className:`w-4 h-4 relative z-10 group-hover:translate-x-1 transition-transform flex-shrink-0`})]}),(0,R.jsx)(b,{to:`/services`,className:`group relative inline-flex items-center justify-center gap-2 px-5 sm:px-6 py-3 rounded-full font-bold text-white border-2 border-white/30 hover:border-white hover:bg-white/10 transition-all backdrop-blur-sm text-xs sm:text-sm md:text-base w-full xs:w-auto`,children:`Explore Our Services`})]}),(0,R.jsx)(S.div,{variants:V,className:`mt-6 sm:mt-8 hidden lg:flex flex-wrap lg:justify-start gap-1.5 sm:gap-2 md:gap-3 w-full`,children:[`Custom Web Dev`,`CRM Solutions`,`Web Development`,`Digital Transformation`].map((e,t)=>(0,R.jsxs)(S.div,{initial:{opacity:0,y:20,scale:.9},animate:{opacity:1,y:0,scale:1},transition:{duration:.5,delay:.6+t*.1,type:`spring`,stiffness:100},whileHover:{y:-5,scale:1.05},className:`px-2.5 sm:px-3.5 md:px-4 py-1.5 sm:py-2 rounded-full border border-white/40 text-[9px] sm:text-[11px] md:text-xs font-bold text-white bg-white/10 backdrop-blur-md shadow-lg flex items-center gap-1.5 sm:gap-2 cursor-default max-w-full`,children:[(0,R.jsxs)(`div`,{className:`relative flex h-2 w-2 sm:h-2.5 sm:w-2.5 flex-shrink-0`,children:[(0,R.jsx)(`span`,{className:`animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-300 opacity-75`}),(0,R.jsx)(`span`,{className:`relative inline-flex rounded-full h-2 w-2 sm:h-2.5 sm:w-2.5 bg-emerald-100`})]}),(0,R.jsx)(`span`,{className:`break-words`,children:e})]},e))})]}),(0,R.jsx)(S.div,{initial:{opacity:0,x:40},animate:{opacity:1,x:0},transition:{duration:.5,delay:.1,ease:[.22,1,.36,1]},className:`lg:col-span-5 relative w-full self-stretch h-[340px] xs:h-[380px] sm:h-[460px] md:h-[500px] lg:h-auto min-h-0 lg:min-h-[480px] overflow-hidden`,children:(0,R.jsxs)(`div`,{className:`absolute inset-0 overflow-hidden flex gap-2 sm:gap-4 md:gap-5 px-0 sm:px-1`,children:[(0,R.jsx)(`div`,{className:`flex-1 min-w-0 overflow-hidden`,children:(0,R.jsx)(`div`,{className:`flex flex-col gap-3 sm:gap-4 md:gap-5 animate-marquee-vertical-slow`,children:[...z,...z].map((t,n)=>(0,R.jsx)(`div`,{className:`w-full rounded-xl sm:rounded-2xl overflow-hidden border border-slate-100 bg-white shadow-md shrink-0 h-40 xs:h-44 sm:h-52 md:h-56 lg:h-64 flex items-center justify-center cursor-pointer hover:scale-[1.02] transition-transform`,onClick:()=>e(`/${t.slug}`),children:(0,R.jsx)(`img`,{src:t.img,alt:t.title,fetchPriority:`high`,decoding:`async`,className:`w-full h-full object-contain`})},`col1-${n}`))})}),(0,R.jsx)(`div`,{className:`flex-1 min-w-0 overflow-hidden`,children:(0,R.jsx)(`div`,{className:`flex flex-col gap-3 sm:gap-4 md:gap-5 animate-marquee-vertical-reverse pt-6 sm:pt-10`,children:[...B,...B].map((t,n)=>(0,R.jsx)(`div`,{className:`w-full rounded-xl sm:rounded-2xl overflow-hidden border border-slate-100 bg-white shadow-md shrink-0 h-44 xs:h-48 sm:h-56 md:h-64 lg:h-72 flex items-center justify-center cursor-pointer hover:scale-[1.02] transition-transform`,onClick:()=>e(`/${t.slug}`),children:(0,R.jsx)(`img`,{src:t.img,alt:t.title,fetchPriority:`high`,decoding:`async`,className:`w-full h-full object-contain`})},`col2-${n}`))})})]})}),(0,R.jsx)(S.div,{variants:V,className:`flex lg:hidden flex-wrap justify-center col-span-full gap-1.5 sm:gap-2 md:gap-3 w-full mt-2 sm:mt-4`,children:[`Custom Web Dev`,`CRM Solutions`,`Web Development`,`Digital Transformation`].map((e,t)=>(0,R.jsxs)(S.div,{initial:{opacity:0,y:20,scale:.9},animate:{opacity:1,y:0,scale:1},transition:{duration:.5,delay:.6+t*.1,type:`spring`,stiffness:100},className:`px-2.5 sm:px-3.5 md:px-4 py-1.5 sm:py-2 rounded-full border border-white/40 text-[9px] sm:text-[11px] md:text-xs font-bold text-white bg-white/10 backdrop-blur-md shadow-lg flex items-center gap-1.5 sm:gap-2 cursor-default max-w-full`,children:[(0,R.jsxs)(`div`,{className:`relative flex h-2 w-2 sm:h-2.5 sm:w-2.5 flex-shrink-0`,children:[(0,R.jsx)(`span`,{className:`animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-300 opacity-75`}),(0,R.jsx)(`span`,{className:`relative inline-flex rounded-full h-2 w-2 sm:h-2.5 sm:w-2.5 bg-emerald-100`})]}),(0,R.jsx)(`span`,{className:`break-words`,children:e})]},`mob-${e}`))}),(0,R.jsx)(S.div,{variants:V,initial:`hidden`,animate:`visible`,className:`lg:hidden col-span-full w-full flex items-center justify-center -mt-2 sm:mt-0`,children:(0,R.jsx)(b,{to:`/services`,className:`group relative inline-flex items-center justify-center gap-2 px-6 sm:px-7 py-3 rounded-full font-bold text-white bg-[#F97316] border-2 border-[#F97316] hover:bg-[#ea580c] hover:border-[#ea580c] transition-all backdrop-blur-sm text-xs sm:text-sm w-full xs:w-auto`,children:`Explore Our Services`})})]})]})}function U({value:e,inView:t}){let n=e.replace(/[^0-9]/g,``),r=e.replace(/[0-9]/g,``),i=parseInt(n,10),[a,o]=(0,L.useState)(0),s=(0,L.useRef)(!1);return(0,L.useEffect)(()=>{if(!t||s.current)return;s.current=!0;let e=0,n=i/72,r=setInterval(()=>{e+=n,e>=i?(o(i),clearInterval(r)):o(Math.floor(e))},1e3/60);return()=>clearInterval(r)},[t,i]),(0,R.jsxs)(R.Fragment,{children:[a,r]})}function W(){let e=(0,L.useRef)(null),t=w(e,{once:!0,amount:.2});return(0,R.jsx)(`section`,{className:`
        relative
        z-10

        
        -mt-4

        
        sm:-mt-6

        
        md:-mt-8

        
        lg:-mt-20

        pb-2
        sm:pb-4
        md:pb-6
      `,children:(0,R.jsx)(`div`,{className:`
          container-x
          mx-auto
          w-full
          px-4
          sm:px-6
          lg:px-8
        `,children:(0,R.jsx)(S.div,{ref:e,initial:{opacity:0,y:40},animate:t?{opacity:1,y:0}:{},transition:{duration:.5,ease:`easeOut`},className:`
            w-full
            rounded-2xl
            bg-white
            border
            border-slate-100
            shadow-xl

            
            px-4
            py-3

            sm:rounded-3xl
            sm:px-5
            sm:py-4

            md:px-6
            md:py-5

            
            lg:px-10
            lg:py-7

            grid
            grid-cols-2

            
            gap-y-4
            gap-x-3

            sm:gap-y-5
            sm:gap-x-5

            md:grid-cols-4
            md:gap-6
          `,children:E.map((e,n)=>(0,R.jsxs)(S.div,{initial:{opacity:0,scale:.8},animate:t?{opacity:1,scale:1}:{},transition:{duration:.5,delay:n*.1},className:`
                relative
                flex
                flex-col
                items-center
                justify-center
                text-center
                min-w-0
              `,children:[(0,R.jsx)(`div`,{className:`
                  whitespace-nowrap
                  text-[28px]
                  font-extrabold
                  tracking-tight
                  text-[#009B6C]
                  leading-none

                  xs:text-[34px]
                  sm:text-[42px]
                  md:text-[42px]
                  lg:text-[54px]
                `,children:(0,R.jsx)(U,{value:e.value,inView:t})}),(0,R.jsx)(`div`,{className:`
                  mt-1.5
                  max-w-[130px]
                  text-xs
                  font-semibold
                  leading-snug
                  text-slate-600

                  sm:mt-2
                  sm:max-w-none
                  sm:text-sm

                  md:text-base
                `,children:e.label}),n<E.length-1&&(0,R.jsx)(`div`,{className:`
                    absolute
                    -right-2
                    top-1/2
                    hidden
                    h-12
                    -translate-y-1/2
                    border-r
                    border-slate-200

                    sm:-right-3

                    md:hidden
                  `}),n<2&&(0,R.jsx)(`div`,{className:`
                    absolute
                    -bottom-3
                    left-1/2
                    w-[80%]
                    -translate-x-1/2
                    border-b
                    border-slate-100

                    sm:-bottom-4

                    md:hidden
                  `})]},e.label))})})})}function G(){let e=y();return(0,R.jsxs)(`section`,{className:`
        relative
        overflow-hidden

        pt-8
        sm:pt-10
        md:pt-12
        lg:pt-14

        pb-10
        sm:pb-12
        md:pb-16
        lg:pb-20

        bg-[#e8f7f2]
      `,children:[(0,R.jsx)(`div`,{className:`
          blob-1
          absolute
          -top-24
          -left-24

          w-48
          h-48

          sm:w-64
          sm:h-64

          md:w-72
          md:h-72

          bg-emerald-200/30
          rounded-full
          blur-3xl

          pointer-events-none
        `}),(0,R.jsx)(`div`,{className:`
          blob-2
          absolute
          -bottom-24
          -right-20

          w-64
          h-64

          sm:w-80
          sm:h-80

          md:w-96
          md:h-96

          bg-teal-200/20
          rounded-full
          blur-3xl

          pointer-events-none
        `}),(0,R.jsxs)(`div`,{className:`container-x`,children:[(0,R.jsx)(`div`,{className:`
            text-center
            max-w-3xl
            mx-auto

            mb-8
            sm:mb-10
            md:mb-12
          `,children:(0,R.jsxs)(S.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.2},transition:{duration:.4},className:`
              flex
              flex-col
              items-center
            `,children:[(0,R.jsx)(A,{icon:g,children:`What We Do`}),(0,R.jsxs)(`h2`,{className:`
                mt-3
                sm:mt-4

                text-2xl
                sm:text-3xl
                md:text-4xl
                lg:text-5xl

                font-extrabold
                text-slate-900

                leading-tight

                px-2
              `,children:[`Our `,(0,R.jsx)(`span`,{className:`text-[#009B6C]`,children:`IT Services`})]}),(0,R.jsx)(`p`,{className:`
                mt-3
                sm:mt-4

                text-slate-500

                text-sm
                sm:text-base

                leading-relaxed

                max-w-2xl

                px-2
                sm:px-4
              `,children:(0,R.jsx)(j,{mode:`words`,text:`Comprehensive digital solutions tailored for growth-stage businesses. From custom software architecture to intelligent automation and data-driven marketing.`})})]})}),(0,R.jsx)(`div`,{className:`
            grid

            grid-cols-1
            sm:grid-cols-2
            lg:grid-cols-3
            xl:grid-cols-4

            gap-4
            sm:gap-5
            md:gap-6
          `,children:D.map((t,n)=>(0,R.jsxs)(S.div,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.1},transition:{duration:.5,delay:n*.05},whileHover:{y:-6,boxShadow:`0 16px 40px -8px rgba(0,155,108,0.18)`},onClick:()=>e(`/${t.slug}`),className:`
                w-full
                min-w-0

                bg-white

                rounded-xl
                sm:rounded-2xl

                border
                border-slate-100

                shadow-sm

                overflow-hidden

                flex
                flex-col
                group

                cursor-pointer

                transition-all
                duration-300
              `,children:[(0,R.jsxs)(`div`,{className:`
                  relative
                  overflow-hidden

                  w-full

                  h-40
                  sm:h-44
                  md:h-48
                  lg:h-52

                  bg-white

                  flex
                  items-center
                  justify-center

                  p-3
                  sm:p-4

                  rounded-t-xl
                  sm:rounded-t-2xl

                  border-b
                  border-slate-100
                `,children:[(0,R.jsx)(`img`,{src:t.img,alt:t.title,className:`
                    w-full
                    h-full

                    object-contain
                    object-center

                    transition-transform
                    duration-500

                    rounded-lg
                    sm:rounded-xl
                    ${t.slug===`digital-marketing`?`scale-[1.38] group-hover:scale-[1.44]`:t.slug===`crm-erp-development`?`max-w-[96%] max-h-[96%] group-hover:scale-[1.04]`:`max-w-[94%] max-h-[94%] group-hover:scale-[1.04]`}
                  `}),(0,R.jsx)(`div`,{className:`
                    absolute
                    inset-0

                    bg-[#009B6C]/0
                    group-hover:bg-[#009B6C]/5

                    transition-colors
                    duration-300

                    pointer-events-none

                    rounded-lg
                    sm:rounded-xl
                  `})]}),(0,R.jsxs)(`div`,{className:`
                  p-4
                  sm:p-5

                  flex
                  flex-col
                  flex-grow

                  items-center
                  text-center
                `,children:[(0,R.jsx)(`h3`,{className:`
                    w-full

                    text-base
                    sm:text-lg
                    md:text-xl

                    font-extrabold

                    text-[#009B6C]

                    leading-tight

                    group-hover:text-[#007a55]

                    transition-colors
                  `,children:t.title}),(0,R.jsx)(`p`,{className:`
                    mt-2

                    text-slate-500

                    text-xs
                    sm:text-sm

                    leading-relaxed

                    flex-grow

                    max-w-sm
                  `,children:t.desc}),(0,R.jsxs)(b,{to:`/${t.slug}`,className:`
                    mt-4

                    inline-flex
                    items-center
                    justify-center

                    gap-1.5

                    text-[#009B6C]

                    font-semibold

                    text-xs
                    sm:text-sm

                    group-hover:text-[#007a55]

                    transition-colors

                    whitespace-nowrap
                  `,children:[`Explore Service`,(0,R.jsx)(u,{className:`
                      w-3.5
                      h-3.5

                      sm:w-4
                      sm:h-4

                      group-hover:translate-x-1

                      transition-transform
                    `})]})]})]},t.slug))})]})]})}var K={Lightbulb:f,Layers:t,Code2:r,Hourglass:i,CloudUpload:n,RefreshCw:h};function q(){return(0,R.jsx)(`section`,{className:`py-10 sm:py-12 md:py-16 lg:py-20 bg-emerald-50/60`,children:(0,R.jsxs)(`div`,{className:`container-x px-4 sm:px-6 lg:px-8`,children:[(0,R.jsxs)(S.div,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.3},className:`text-center max-w-2xl mx-auto mb-8 sm:mb-10`,children:[(0,R.jsx)(A,{icon:s,children:`Our Process`}),(0,R.jsx)(`h2`,{className:`mt-4 text-2xl sm:text-3xl md:text-5xl font-bold text-slate-900`,children:(0,R.jsx)(j,{text:`Our Custom Software Strategy`})}),(0,R.jsx)(`p`,{className:`mt-4 text-sm sm:text-base text-slate-600 px-2`,children:`We follow a structured software development lifecycle focused on planning, scalability, performance, and long-term support.`})]}),(0,R.jsxs)(`div`,{className:`mt-8 relative`,children:[(0,R.jsx)(`div`,{className:`hidden lg:block absolute left-4 right-4 top-1/2 -translate-y-1/2 h-[40px] overflow-hidden opacity-50 z-0 pointer-events-none`,children:(0,R.jsx)(S.div,{animate:{x:[-200,0]},transition:{repeat:1/0,duration:3,ease:`linear`},className:`w-[calc(100%+400px)] h-full`,style:{backgroundImage:`url("data:image/svg+xml,%3Csvg width='200' height='40' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 20 Q 50 40, 100 20 T 200 20' fill='none' stroke='%2310b981' stroke-width='2.5' stroke-linecap='round' stroke-dasharray='8 8' /%3E%3C/svg%3E")`,backgroundSize:`200px 40px`,backgroundRepeat:`repeat-x`}})}),(0,R.jsx)(`div`,{className:`grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-5 lg:gap-6 relative z-10`,children:k.map((e,t)=>{let n=K[e.icon];return(0,R.jsx)(S.div,{initial:{opacity:0,y:40,scale:.9},whileInView:{opacity:1,y:0,scale:1},viewport:{once:!0,amount:.05},transition:{duration:.5,delay:t*.1},className:`relative z-10`,children:(0,R.jsxs)(S.div,{animate:{y:[0,-8,0]},transition:{repeat:1/0,duration:4+t%2,ease:`easeInOut`,delay:t*.3},whileHover:{scale:1.05,y:-12,transition:{duration:.2}},className:`bg-white h-full rounded-2xl border border-emerald-100 p-4 sm:p-6 text-center shadow-sm hover:shadow-xl hover:shadow-emerald-900/5 transition-all`,children:[(0,R.jsx)(`div`,{className:`w-14 h-14 mx-auto rounded-xl bg-emerald-100 grid place-items-center text-emerald-600 relative overflow-hidden`,children:(0,R.jsx)(S.div,{animate:{scale:[1,1.15,1]},transition:{repeat:1/0,duration:3,ease:`easeInOut`,delay:t*.2},children:(0,R.jsx)(n,{className:`w-6 h-6`})})}),(0,R.jsx)(`div`,{className:`mt-5 text-emerald-600 font-bold text-xs uppercase tracking-wider`,children:e.step}),(0,R.jsx)(`h4`,{className:`mt-2 font-extrabold text-slate-900 text-sm sm:text-base`,children:e.title})]})},e.step)})})]})]})})}var J={id:1,name:`Verified Client`,role:`Founder`,company:`Raaf Beauty`,rating:5,src:`/videos/testimonial-1.mp4`,poster:``,quote:`An amazing experience working with the team. They delivered outstanding results for Raaf Beauty, transforming our digital presence completely.`};function Y({rating:e=5}){return(0,R.jsxs)(`div`,{className:`flex flex-wrap items-center gap-1.5 mb-5`,children:[[...Array(Math.floor(e))].map((e,t)=>(0,R.jsx)(_,{className:`
            w-4 h-4
            sm:w-5 sm:h-5
            fill-amber-400
            text-amber-400
          `},`full-${t}`)),(0,R.jsxs)(`span`,{className:`
          ml-1 sm:ml-2
          text-xs sm:text-sm
          font-bold
          text-slate-600
        `,children:[e.toFixed(1),` / 5.0`]})]})}function X(){let e=(0,L.useRef)(null),[t,n]=(0,L.useState)(!1),[r,i]=(0,L.useState)(!1),[o,s]=(0,L.useState)(!0);return(0,R.jsxs)(`section`,{className:`
        relative
        overflow-hidden

        py-2
        sm:py-3
        md:py-4

        bg-[#eef5f2]
      `,children:[(0,R.jsx)(S.div,{animate:{scale:[1,1.2,1],opacity:[.3,.6,.3],x:[0,30,0],y:[0,-20,0]},transition:{duration:8,repeat:1/0,ease:`easeInOut`},className:`
          absolute
          -top-20 sm:-top-10
          left-1/4
          w-56 sm:w-72 md:w-96
          h-56 sm:h-72 md:h-96
          bg-emerald-300/40
          rounded-full
          blur-3xl
          pointer-events-none
        `}),(0,R.jsx)(S.div,{animate:{scale:[1,1.3,1],opacity:[.2,.5,.2],x:[0,-40,0],y:[0,30,0]},transition:{duration:10,repeat:1/0,ease:`easeInOut`,delay:1},className:`
          absolute
          -bottom-20
          right-1/4
          w-52 sm:w-64 md:w-80
          h-52 sm:h-64 md:h-80
          bg-teal-300/30
          rounded-full
          blur-3xl
          pointer-events-none
        `}),(0,R.jsxs)(`div`,{className:`container-x relative z-10 w-full max-w-6xl mx-auto`,children:[(0,R.jsxs)(S.div,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.2},transition:{duration:.4},className:`
            text-center

            w-full

            max-w-2xl

            mx-auto

            mb-4
            sm:mb-6
            md:mb-8
          `,children:[(0,R.jsx)(A,{children:`Client Success`}),(0,R.jsxs)(`h2`,{className:`
              mt-3
              sm:mt-4

              text-2xl
              sm:text-3xl
              md:text-4xl
              lg:text-5xl

              font-extrabold

              text-slate-900

              leading-tight

              px-2
            `,children:[`Hear It From `,(0,R.jsx)(`span`,{className:`text-emerald-600`,children:`Our Clients`})]}),(0,R.jsx)(`p`,{className:`
              mt-3
              sm:mt-4

              text-sm
              sm:text-base

              text-slate-500

              leading-relaxed

              px-2
            `,children:`Real experiences from businesses we've helped grow digitally.`})]}),(0,R.jsxs)(`div`,{className:`
            grid

            grid-cols-1

            lg:grid-cols-2

            gap-6
            sm:gap-8
            lg:gap-10

            items-center
          `,children:[(0,R.jsx)(S.div,{initial:{opacity:0,x:-40},whileInView:{opacity:1,x:0},viewport:{once:!0,amount:.2},transition:{duration:.6},className:`
              relative
              w-fit
              mx-auto
              group
              rounded-2xl
              sm:rounded-3xl
              overflow-hidden
              shadow-xl
              sm:shadow-2xl
              border-2
              sm:border-4
              border-white
              bg-black
            `,children:(0,R.jsxs)(`div`,{className:`
                relative
                flex
                justify-center
                bg-black
                cursor-pointer
                overflow-hidden
              `,onClick:async()=>{if(!(!e.current||!o))try{t?(e.current.pause(),n(!1)):(await e.current.play(),n(!0))}catch(e){console.error(`Video play error:`,e),s(!1)}},children:[(0,R.jsx)(`video`,{ref:e,src:J.src,poster:J.poster||void 0,className:`
                  w-auto
                  h-[350px]
                  sm:h-[450px]
                  md:h-[500px]
                  object-contain
                  block
                  bg-black
                  transition-opacity
                  duration-300
                  ${o?`opacity-100`:`opacity-0`}
                `,playsInline:!0,muted:r,loop:!0,preload:`metadata`,onError:()=>s(!1),onPlay:()=>n(!0),onPause:()=>n(!1)}),!t&&o&&(0,R.jsx)(`div`,{className:`
                    absolute
                    inset-0
                    bg-gradient-to-br
                    from-slate-900/20
                    to-slate-900/60
                    flex
                    items-center
                    justify-center
                    z-10
                  `,children:(0,R.jsx)(`div`,{className:`
                      w-14
                      h-14

                      sm:w-16
                      sm:h-16

                      md:w-20
                      md:h-20

                      rounded-full

                      bg-white/20

                      backdrop-blur-md

                      flex
                      items-center
                      justify-center

                      border
                      border-white/30

                      group-hover:scale-110

                      transition-transform
                      duration-300
                    `,children:(0,R.jsx)(l,{className:`
                        w-6
                        h-6

                        sm:w-7
                        sm:h-7

                        md:w-8
                        md:h-8

                        text-white

                        ml-1
                      `})})}),t&&(0,R.jsx)(`div`,{className:`
                    absolute
                    inset-0
                    -mb-6 sm:-mb-10 md:-mb-14

                    flex
                    items-center
                    justify-center

                    opacity-0
                    group-hover:opacity-100

                    transition-opacity

                    z-10

                    bg-black/10
                  `,children:(0,R.jsx)(`div`,{className:`
                      w-12
                      h-12

                      sm:w-14
                      sm:h-14

                      md:w-16
                      md:h-16

                      rounded-full

                      bg-black/40

                      backdrop-blur-md

                      flex
                      items-center
                      justify-center

                      border
                      border-white/20
                    `,children:(0,R.jsx)(v,{className:`
                        w-5
                        h-5

                        sm:w-6
                        sm:h-6

                        text-white
                      `})})}),t&&(0,R.jsx)(`div`,{className:`
                    absolute

                    top-3
                    right-3

                    sm:top-4
                    sm:right-4

                    z-30
                  `,children:(0,R.jsx)(`button`,{type:`button`,onClick:t=>{if(t.stopPropagation(),!e.current)return;let n=!r;e.current.muted=n,i(n)},"aria-label":r?`Unmute video`:`Mute video`,className:`
                      w-9
                      h-9

                      sm:w-10
                      sm:h-10

                      rounded-full

                      bg-black/50

                      backdrop-blur-md

                      flex
                      items-center
                      justify-center

                      border
                      border-white/20

                      hover:bg-black/70

                      transition-colors
                    `,children:r?(0,R.jsx)(a,{className:`
                          w-4
                          h-4

                          sm:w-5
                          sm:h-5

                          text-white
                        `}):(0,R.jsx)(c,{className:`
                          w-4
                          h-4

                          sm:w-5
                          sm:h-5

                          text-white
                        `})})}),!o&&(0,R.jsx)(`div`,{className:`
                    absolute
                    inset-0
                    -mb-6 sm:-mb-10 md:-mb-14

                    bg-slate-800

                    flex
                    items-center
                    justify-center

                    text-center

                    p-5

                    z-20
                  `,children:(0,R.jsxs)(`div`,{children:[(0,R.jsx)(`p`,{className:`
                        text-white

                        font-semibold

                        text-sm
                        sm:text-base
                      `,children:`Video unavailable`}),(0,R.jsx)(`p`,{className:`
                        text-white/60

                        text-xs

                        mt-1
                      `,children:`Please try again later.`})]})})]})}),(0,R.jsxs)(S.div,{initial:{opacity:0,x:40},whileInView:{opacity:1,x:0},viewport:{once:!0,amount:.2},transition:{duration:.6,delay:.2},className:`
              flex
              flex-col

              w-full

              text-center

              lg:text-left

              items-center

              lg:items-start
            `,children:[(0,R.jsx)(Y,{rating:J.rating}),(0,R.jsxs)(`h3`,{className:`
                text-xl
                sm:text-2xl
                md:text-3xl
                lg:text-4xl

                font-bold

                text-slate-800

                leading-[1.35]

                mb-6
                sm:mb-8

                max-w-xl
              `,children:[`"`,J.quote,`"`]}),(0,R.jsxs)(`div`,{className:`
                flex

                items-center

                justify-center
                lg:justify-start

                gap-3
                sm:gap-4
              `,children:[(0,R.jsx)(p,{className:`
                  w-8
                  h-8

                  sm:w-10
                  sm:h-10

                  text-[#009B6C]
                  flex-shrink-0
                `,fill:`currentColor`,stroke:`white`}),(0,R.jsxs)(`div`,{className:`text-left`,children:[(0,R.jsx)(`div`,{className:`
                    font-bold

                    text-slate-900

                    text-sm
                    sm:text-base
                  `,children:J.name}),(0,R.jsx)(`div`,{className:`
                    text-xs
                    sm:text-sm

                    text-slate-500
                  `})]})]})]})]})]})]})}var Z=({className:e})=>(0,R.jsxs)(`svg`,{xmlns:`http://www.w3.org/2000/svg`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,className:e,children:[(0,R.jsx)(`path`,{d:`M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z`}),(0,R.jsx)(`path`,{d:`M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2`}),(0,R.jsx)(`path`,{d:`M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2`}),(0,R.jsx)(`path`,{d:`M10 6h4`}),(0,R.jsx)(`path`,{d:`M10 10h4`}),(0,R.jsx)(`path`,{d:`M10 14h4`}),(0,R.jsx)(`path`,{d:`M10 18h4`})]});function Q(){let e=[...T.slice(0,6),...T.slice(0,6)],t=[...T.slice(6,12),...T.slice(6,12)];return(0,R.jsx)(`section`,{className:`
        relative
        overflow-hidden

        py-10
        sm:py-12
        md:py-16
        lg:py-20

        bg-emerald-50/60
      `,children:(0,R.jsx)(`div`,{className:`container-x`,children:(0,R.jsxs)(`div`,{className:`
            grid

            grid-cols-1
            lg:grid-cols-12

            gap-8
            sm:gap-10
            lg:gap-12

            items-center
          `,children:[(0,R.jsx)(`div`,{className:`
              lg:col-span-5

              w-full

              flex
              flex-col
              items-start

              text-left
            `,children:(0,R.jsxs)(S.div,{initial:{opacity:0,x:-30},whileInView:{opacity:1,x:0},viewport:{once:!0,amount:.2},transition:{duration:.5},className:`w-full`,children:[(0,R.jsx)(A,{icon:Z,children:`Industries`}),(0,R.jsxs)(`h2`,{className:`
                  mt-3
                  sm:mt-4

                  text-3xl
                  sm:text-4xl
                  md:text-5xl

                  font-bold

                  leading-[1.15]

                  whitespace-normal
                `,children:[(0,R.jsxs)(`span`,{className:`text-slate-900`,children:[`Industries`,` `]}),(0,R.jsx)(S.span,{initial:{opacity:0,y:40,rotateX:-60},whileInView:{opacity:1,y:0,rotateX:0},viewport:{once:!0},transition:{duration:.7,delay:.2,ease:[.22,1,.36,1]},style:{display:`inline-block`,transformOrigin:`top center`},className:`text-emerald-600`,children:`We Serve`})]}),(0,R.jsx)(`p`,{className:`
                  mt-4
                  sm:mt-5
                  md:mt-6

                  text-slate-600

                  text-sm
                  sm:text-base
                  md:text-lg
                  lg:text-xl

                  leading-relaxed

                  max-w-xl
                `,children:`White Gravity delivers innovative digital solutions for businesses across multiple sectors. From healthcare and real estate to e-commerce and finance, we build custom tech that scales and transforms your operations.`}),(0,R.jsx)(`div`,{className:`
                  mt-6
                  sm:mt-8
                  md:mt-10
                `,children:(0,R.jsxs)(b,{to:`/industries`,className:`
                    group

                    inline-flex

                    items-center
                    justify-center

                    gap-2
                    sm:gap-3

                    px-5
                    sm:px-6
                    md:px-8

                    py-3
                    sm:py-3.5
                    md:py-4

                    rounded-full

                    font-semibold

                    bg-white

                    border
                    border-slate-200

                    text-slate-800

                    transition-all

                    hover:shadow-[0_8px_30px_-4px_rgba(16,185,129,0.2)]

                    hover:border-emerald-300

                    hover:text-emerald-700

                    text-xs
                    sm:text-sm
                    md:text-base
                  `,children:[(0,R.jsx)(`span`,{children:`View All Industries`}),(0,R.jsx)(u,{className:`
                      w-4
                      h-4

                      sm:w-5
                      sm:h-5

                      group-hover:translate-x-1

                      transition-transform

                      flex-shrink-0
                    `})]})})]})}),(0,R.jsx)(`div`,{className:`
              lg:col-span-7

              relative

              w-full

              min-w-0
            `,children:(0,R.jsxs)(`div`,{className:`
                relative

                w-full
                lg:w-[200%]

                h-[250px]
                xs:h-[280px]
                sm:h-[340px]
                md:h-[440px]
                lg:h-[500px]

                flex
                flex-col

                gap-3
                sm:gap-4
                md:gap-6

                justify-center

                overflow-hidden

                rounded-2xl
                sm:rounded-3xl

                lg:rounded-l-3xl
                lg:rounded-r-none

                pause-on-hover
              `,children:[(0,R.jsx)(`div`,{className:`
                  w-full

                  overflow-hidden

                  relative
                `,children:(0,R.jsx)(`div`,{className:`
                    flex

                    gap-3
                    sm:gap-4
                    md:gap-6

                    w-max

                    animate-marquee-industries
                  `,children:e.map((e,t)=>(0,R.jsx)($,{industry:e},`row1-${t}`))})}),(0,R.jsx)(`div`,{className:`
                  w-full

                  overflow-hidden

                  relative
                `,children:(0,R.jsx)(`div`,{className:`
                    flex

                    gap-3
                    sm:gap-4
                    md:gap-6

                    w-max

                    animate-marquee-reverse-industries

                    ml-4
                    sm:ml-8
                    md:ml-12
                  `,children:t.map((e,t)=>(0,R.jsx)($,{industry:e},`row2-${t}`))})})]})})]})})})}function $({industry:e}){return(0,R.jsxs)(`div`,{className:`
        relative

        rounded-xl
        sm:rounded-2xl
        md:rounded-[24px]

        overflow-hidden

        shadow-md

        shrink-0

        w-[180px]
        xs:w-[200px]
        sm:w-[240px]
        md:w-[280px]
        lg:w-[300px]

        aspect-[16/9]

        group

        cursor-pointer
      `,children:[(0,R.jsx)(`img`,{src:e.img,alt:e.name,className:`
          w-full
          h-full

          object-cover

          group-hover:scale-105

          transition-transform
          duration-700
        `}),(0,R.jsx)(`div`,{className:`
          absolute
          inset-0

          bg-gradient-to-t
          from-slate-900/90
          via-slate-900/20
          to-transparent

          opacity-80

          group-hover:opacity-100

          transition-opacity
          duration-300
        `}),(0,R.jsx)(`div`,{className:`
          absolute

          inset-x-1
          sm:inset-x-2

          bottom-2
          sm:bottom-3
          md:bottom-4

          text-center

          text-white

          px-1
          sm:px-2
        `,children:(0,R.jsx)(`div`,{className:`
            font-extrabold

            text-[11px]
            sm:text-sm
            md:text-lg

            tracking-wide

            leading-tight
          `,children:e.name})})]})}var te=[{question:`What services do you offer?`,answer:`We provide a full suite of digital solutions, including Custom Software Development, Website & App Development, eCommerce Solutions, CRM/ERP Integration (Zoho), and Performance Marketing (Google/Meta Ads).`},{question:`How much time does it take to build a website or app?`,answer:`A standard website typically takes about 2 to 4 weeks, while complex web or mobile applications can take 2 to 3 months depending on the features and technical requirements.`},{question:`Do you provide maintenance and support after launch?`,answer:`Yes! We offer comprehensive maintenance and support plans to ensure your website or software stays secure, updated, and running smoothly without any downtime.`},{question:`What makes White Gravity different from other agencies?`,answer:`We combine high-quality engineering, agile sprint-based delivery, and strategic digital marketing under one roof. Our focus is on building scalable technology that drives real ROI for your business.`}];function ne(){let[e,t]=(0,L.useState)(0);return(0,R.jsxs)(`section`,{className:`relative overflow-hidden bg-white py-12 sm:py-16 md:py-20 lg:py-24`,children:[(0,R.jsx)(`div`,{className:`pointer-events-none absolute -left-32 top-20 h-64 w-64 rounded-full bg-emerald-100/40 blur-3xl`}),(0,R.jsx)(`div`,{className:`pointer-events-none absolute -right-32 bottom-10 h-72 w-72 rounded-full bg-teal-100/30 blur-3xl`}),(0,R.jsxs)(`div`,{className:`container-x relative z-10 mx-auto w-full max-w-4xl px-4 sm:px-6 lg:px-8`,children:[(0,R.jsxs)(S.div,{initial:{opacity:0,y:25},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.5},className:`mb-8 flex flex-col items-center text-center sm:mb-10 md:mb-12`,children:[(0,R.jsx)(A,{icon:o,children:`FAQs`}),(0,R.jsxs)(`h2`,{className:`
              mt-4
              text-2xl
              font-extrabold
              leading-tight
              text-slate-900
              sm:text-3xl
              md:text-4xl
              lg:text-5xl
            `,children:[(0,R.jsx)(j,{text:`Frequently Asked `}),(0,R.jsx)(`span`,{className:`text-emerald-600`,children:(0,R.jsx)(j,{text:`Questions`})})]}),(0,R.jsx)(`p`,{className:`
              mt-3
              max-w-2xl
              px-2
              text-sm
              leading-relaxed
              text-slate-600
              sm:mt-4
              sm:text-base
              md:text-lg
            `,children:`Find answers to common questions about our services, process, and how we can help your business grow.`})]}),(0,R.jsx)(`div`,{className:`space-y-3 sm:space-y-4`,children:te.map((n,r)=>{let i=e===r;return(0,R.jsxs)(S.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.2},transition:{duration:.4,delay:r*.08},className:`
                  overflow-hidden
                  rounded-xl
                  border
                  transition-all
                  duration-300
                  sm:rounded-2xl
                  ${i?`border-emerald-300 bg-emerald-50/60 shadow-md`:`border-slate-200 bg-white hover:border-emerald-200 hover:shadow-sm`}
                `,children:[(0,R.jsxs)(`button`,{type:`button`,onClick:()=>t(i?-1:r),"aria-expanded":i,className:`
                    group
                    flex
                    w-full
                    items-center
                    justify-between
                    gap-3
                    px-4
                    py-4
                    text-left
                    focus:outline-none
                    sm:gap-4
                    sm:px-5
                    sm:py-5
                    md:px-6
                  `,children:[(0,R.jsx)(`span`,{className:`
                      min-w-0
                      flex-1
                      text-sm
                      font-bold
                      leading-snug
                      transition-colors
                      duration-300
                      sm:text-base
                      md:text-lg
                      ${i?`text-emerald-700`:`text-slate-800`}
                    `,children:n.question}),(0,R.jsx)(`div`,{className:`
                      flex
                      h-8
                      w-8
                      flex-shrink-0
                      items-center
                      justify-center
                      rounded-full
                      transition-all
                      duration-300
                      sm:h-9
                      sm:w-9
                      md:h-10
                      md:w-10
                      ${i?`rotate-180 bg-emerald-600 text-white`:`bg-slate-100 text-slate-500 group-hover:bg-emerald-100 group-hover:text-emerald-600`}
                    `,children:(0,R.jsx)(d,{className:`h-4 w-4 sm:h-5 sm:w-5`})})]}),(0,R.jsx)(x,{initial:!1,children:i&&(0,R.jsx)(S.div,{initial:{height:0,opacity:0},animate:{height:`auto`,opacity:1},exit:{height:0,opacity:0},transition:{duration:.3,ease:`easeInOut`},children:(0,R.jsx)(`div`,{className:`
                          border-t
                          border-emerald-100/70
                          px-4
                          pb-5
                          pt-4
                          text-sm
                          leading-7
                          text-slate-600
                          sm:px-5
                          sm:pb-6
                          sm:pt-4
                          sm:text-base
                          md:px-6
                        `,children:n.answer})})})]},r)})})]})]})}function re(){return(0,R.jsxs)(R.Fragment,{children:[(0,R.jsx)(H,{}),(0,R.jsx)(W,{}),(0,R.jsx)(G,{}),(0,R.jsx)(M,{}),(0,R.jsx)(q,{}),(0,R.jsx)(I,{}),(0,R.jsx)(P,{}),(0,R.jsx)(X,{}),(0,R.jsx)(Q,{}),(0,R.jsx)(ne,{}),(0,R.jsx)(F,{})]})}export{re as default};