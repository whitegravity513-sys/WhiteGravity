import"./rolldown-runtime-B0Z9INg1.js";import{St as e,d as t}from"./vendor-icons-Bnio1rnV.js";import{i as n,o as r}from"./vendor-motion-CgRTMITC.js";import{u as i}from"./index-JNNES1Rb.js";import{t as a}from"./SectionPill-NOJWXeSM.js";import{t as o}from"./AnimatedText-0iEA4vai.js";e();var s=r();function c({rating:e=5}){let n=Math.floor(e),r=e%1>=.5,i=5-n-!!r;return(0,s.jsxs)(`div`,{className:`flex items-center justify-center gap-1`,children:[[...Array(n)].map((e,n)=>(0,s.jsx)(t,{className:`
            w-3 h-3
            sm:w-3.5 sm:h-3.5
            md:w-4 md:h-4
            fill-amber-400
            text-amber-400
          `},`full-${n}`)),r&&(0,s.jsxs)(`div`,{className:`
            relative
            w-3 h-3
            sm:w-3.5 sm:h-3.5
            md:w-4 md:h-4
          `,children:[(0,s.jsx)(t,{className:`
              w-3 h-3
              sm:w-3.5 sm:h-3.5
              md:w-4 md:h-4
              fill-slate-200
              text-slate-300
              absolute
              inset-0
            `}),(0,s.jsx)(`div`,{className:`overflow-hidden w-[50%] absolute inset-0`,children:(0,s.jsx)(t,{className:`
                w-3 h-3
                sm:w-3.5 sm:h-3.5
                md:w-4 md:h-4
                fill-amber-400
                text-amber-400
              `})})]}),[...Array(i)].map((e,n)=>(0,s.jsx)(t,{className:`
            w-3 h-3
            sm:w-3.5 sm:h-3.5
            md:w-4 md:h-4
            fill-slate-200
            text-slate-300
          `},`empty-${n}`)),(0,s.jsx)(`span`,{className:`
          ml-1
          text-[10px]
          sm:text-[11px]
          md:text-xs
          font-extrabold
          text-slate-700
        `,children:e.toFixed(1)})]})}function l({t:e}){return(0,s.jsxs)(`div`,{className:`
        
        w-[220px]
        h-[230px]
        p-4

        
        sm:w-[250px]
        sm:h-[260px]
        sm:p-4.5

        
        md:w-[280px]
        md:h-[280px]
        md:p-5

        flex-shrink-0

        bg-white
        border
        border-emerald-100
        rounded-2xl

        shadow-sm
        hover:shadow-md
        hover:-translate-y-1

        transition-all
        duration-300

        flex
        flex-col
        gap-2.5
        sm:gap-3
      `,children:[(0,s.jsx)(`div`,{className:`
          font-semibold
          text-xs
          sm:text-sm
          text-slate-900
          truncate
          text-center
          w-full
        `,children:e.name}),(0,s.jsx)(c,{rating:e.rating||5}),(0,s.jsx)(`p`,{className:`
          text-[10px]
          sm:text-[11px]
          md:text-xs

          text-slate-600
          leading-relaxed

          overflow-hidden
          flex-grow

          line-clamp-6

          mt-1
        `,children:e.text})]})}function u(){let e=Math.ceil(i.length/2),t=i.slice(0,e),r=i.slice(e),c=[...t,...t,...t,...t],u=[...r,...r,...r,...r];return(0,s.jsxs)(`section`,{className:`
        py-10
        sm:py-12
        md:py-16
        lg:py-20

        bg-[#eef5f2]

        overflow-hidden
      `,children:[(0,s.jsx)(`div`,{className:`container-x px-4 sm:px-6 lg:px-8`,children:(0,s.jsxs)(n.div,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.3},className:`
            text-center
            max-w-2xl
            mx-auto

            mb-8
            sm:mb-10
            md:mb-12
          `,children:[(0,s.jsx)(a,{children:`Testimonials`}),(0,s.jsx)(`h2`,{className:`
              mt-3
              sm:mt-4

              text-2xl
              sm:text-3xl
              md:text-4xl
              lg:text-5xl

              font-extrabold
              text-slate-900
            `,children:(0,s.jsx)(o,{text:`What Our Clients Say`})}),(0,s.jsx)(`p`,{className:`
              mt-3
              sm:mt-4

              text-sm
              sm:text-base

              text-slate-600

              px-2
            `,children:`Real feedback from businesses we've helped transform digitally.`})]})}),(0,s.jsxs)(`div`,{className:`
          relative
          w-full

          flex
          flex-col

          gap-4
          sm:gap-5
          md:gap-6

          overflow-hidden
          pause-on-hover

          py-3
          sm:py-4
        `,children:[(0,s.jsx)(`div`,{className:`
            absolute
            left-0
            top-0
            bottom-0

            w-6
            sm:w-16
            md:w-32

            bg-gradient-to-r
            from-[#eef5f2]
            to-transparent

            z-10
            pointer-events-none
          `}),(0,s.jsx)(`div`,{className:`
            absolute
            right-0
            top-0
            bottom-0

            w-6
            sm:w-16
            md:w-32

            bg-gradient-to-l
            from-[#eef5f2]
            to-transparent

            z-10
            pointer-events-none
          `}),(0,s.jsx)(`div`,{className:`w-full overflow-hidden`,children:(0,s.jsx)(`div`,{className:`
              flex

              gap-3
              sm:gap-4
              md:gap-6

              w-max

              animate-marquee-slow
            `,children:c.map((e,t)=>(0,s.jsx)(l,{t:e},`row1-${t}`))})}),(0,s.jsx)(`div`,{className:`w-full overflow-hidden`,children:(0,s.jsx)(`div`,{className:`
              flex

              gap-3
              sm:gap-4
              md:gap-6

              w-max

              animate-marquee-reverse-slow
            `,children:u.map((e,t)=>(0,s.jsx)(l,{t:e},`row2-${t}`))})})]})]})}export{u as t};