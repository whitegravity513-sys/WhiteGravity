import{a as e}from"./rolldown-runtime-B0Z9INg1.js";import{H as t,Q as n,St as r,at as i,h as a,l as o,o as s,rt as c,t as l}from"./vendor-icons-Bnio1rnV.js";import{i as u,n as d,o as f}from"./vendor-motion-CgRTMITC.js";import{d as p,o as m}from"./index-JNNES1Rb.js";import{t as h}from"./SectionPill-NOJWXeSM.js";import{t as g}from"./AnimatedText-0iEA4vai.js";var _=e(r(),1),v=f();function y({words:e,typingSpeed:t=80,deletingSpeed:n=40,pauseTime:r=2500,textClass:i=``,cursorClass:a=`bg-emerald-300`}){let[o,s]=(0,_.useState)(``),[c,l]=(0,_.useState)(!1),[u,d]=(0,_.useState)(0);return(0,_.useEffect)(()=>{let i,a=e[u%e.length];return c?o===``?(l(!1),d(e=>e+1)):i=setTimeout(()=>{s(a.substring(0,o.length-1))},n):i=o===a?setTimeout(()=>{l(!0)},r):setTimeout(()=>{s(a.substring(0,o.length+1))},t),()=>clearTimeout(i)},[o,c,u,e,t,n,r]),(0,v.jsxs)(`span`,{className:`inline-flex items-center align-middle min-w-[20px]`,children:[(0,v.jsx)(`span`,{className:i,children:o||`​`}),(0,v.jsx)(`span`,{className:`animate-pulse h-[0.95em] w-[4px] sm:w-[5px] ml-2 inline-block rounded-full shadow-[0_0_10px_rgba(52,211,153,0.8)] ${a}`,style:{WebkitTextFillColor:`initial`,color:`initial`}})]})}var b=[l,a,o,c,t,i];function x({item:e,i:t}){let n=b[t%b.length],r=d(),[i,a]=(0,_.useState)(!1);return(0,v.jsx)(u.div,{initial:{opacity:0,y:36},whileInView:{opacity:1,y:0},whileTap:{scale:.98},viewport:{once:!0,margin:`-30px`},transition:{duration:.45,delay:t*.12,ease:[.22,1,.36,1]},className:`w-full`,style:{perspective:1200},onMouseEnter:()=>{i&&r.start({rotateY:180})},onMouseLeave:()=>{i&&r.start({rotateY:0})},children:(0,v.jsxs)(u.div,{initial:{rotateY:180},whileInView:{rotateY:0},animate:r,viewport:{once:!0},transition:{duration:.8,delay:i?0:t*.15,ease:[.25,.46,.45,.94]},onAnimationComplete:()=>{i||a(!0)},className:`
          relative
          h-full
          min-h-[175px]
          w-full
          cursor-pointer

          sm:min-h-[180px]
        `,style:{transformStyle:`preserve-3d`},children:[(0,v.jsxs)(`div`,{className:`
            group
            absolute
            inset-0
            flex
            h-full
            w-full
            flex-col
            items-center
            justify-center
            gap-3
            rounded-2xl
            border
            border-emerald-100
            bg-emerald-50
            p-3
            text-center
            shadow-sm
            transition-all
            duration-300

            hover:border-emerald-300
            hover:bg-emerald-100
            hover:shadow-md

            sm:p-5
          `,style:{backfaceVisibility:`hidden`},children:[(0,v.jsx)(`div`,{className:`
              flex
              h-9
              w-9
              flex-shrink-0
              items-center
              justify-center
              rounded-xl
              bg-white
              shadow-sm
              transition-all
              duration-300

              group-hover:bg-[#009B6C]

              sm:h-11
              sm:w-11
            `,children:(0,v.jsx)(n,{className:`
                h-4
                w-4
                text-[#009B6C]
                transition-colors
                duration-300

                group-hover:text-white

                sm:h-5
                sm:w-5
              `})}),(0,v.jsxs)(`div`,{className:`flex flex-col items-center`,children:[(0,v.jsx)(`h4`,{className:`
                text-[12px]
                font-bold
                leading-snug
                text-slate-800
                transition-colors
                duration-300

                group-hover:text-[#007a55]

                sm:text-sm
              `,children:e.title}),(0,v.jsx)(`p`,{className:`
                mt-1
                max-w-[220px]
                text-[10px]
                leading-relaxed
                text-slate-500

                sm:mt-2
                sm:text-xs
              `,children:e.desc})]})]}),(0,v.jsxs)(`div`,{className:`
            absolute
            inset-0
            flex
            h-full
            w-full
            flex-col
            items-center
            justify-center
            gap-2
            rounded-2xl
            border
            border-emerald-200
            bg-gradient-to-br
            from-[#009B6C]
            to-emerald-600
            p-3
            shadow-lg

            sm:p-5
          `,style:{backfaceVisibility:`hidden`,transform:`rotateY(180deg)`},children:[(0,v.jsx)(`div`,{className:`
              flex
              h-11
              w-11
              items-center
              justify-center
              rounded-full
              bg-white/20

              sm:h-14
              sm:w-14
            `,children:(0,v.jsx)(n,{className:`
                h-6
                w-6
                text-white

                sm:h-7
                sm:w-7
              `})}),(0,v.jsx)(`span`,{className:`
              mt-1
              text-sm
              font-bold
              text-white

              sm:text-base
            `,children:e.title}),(0,v.jsx)(`p`,{className:`
              mt-1
              max-w-[200px]
              text-center
              text-[10px]
              leading-relaxed
              text-white/80

              sm:text-xs
            `,children:e.desc})]})]})})}function S(){return(0,v.jsxs)(`section`,{className:`
        relative
        overflow-hidden
        bg-[#f8fdfb]

        py-12
        sm:py-16
        md:py-20
        lg:py-24
      `,children:[(0,v.jsx)(`div`,{className:`
          blob-2
          pointer-events-none
          absolute
          -right-20
          top-10
          h-64
          w-64
          rounded-full
          bg-emerald-100/40
          blur-3xl

          sm:h-80
          sm:w-80
        `}),(0,v.jsx)(`div`,{className:`
          blob-3
          pointer-events-none
          absolute
          -bottom-20
          -left-20
          h-56
          w-56
          rounded-full
          bg-teal-100/30
          blur-3xl

          sm:h-64
          sm:w-64
        `}),(0,v.jsx)(`div`,{className:`container-x relative z-10`,children:(0,v.jsxs)(`div`,{className:`
            grid
            grid-cols-1
            items-center
            gap-12

            lg:grid-cols-12
            lg:gap-12
            xl:gap-16
          `,children:[(0,v.jsxs)(u.div,{initial:{opacity:0,x:-30},whileInView:{opacity:1,x:0},viewport:{once:!0,amount:.15},transition:{duration:.5},className:`
              w-full
              min-w-0

              lg:col-span-7
            `,children:[(0,v.jsx)(`div`,{className:`
                flex
                justify-center

                lg:justify-start
              `,children:(0,v.jsx)(h,{icon:s,className:`!text-sm sm:!text-base !px-5 !py-2 !font-bold shadow-sm`,children:`Why Us`})}),(0,v.jsxs)(`h2`,{className:`
                mt-5
                text-center
                text-4xl
                font-bold
                leading-[1.12]
                text-[#009B6C]

                sm:text-4xl
                md:text-5xl

                lg:text-left
                lg:text-[48px]

                xl:text-[52px]
              `,children:[(0,v.jsxs)(`span`,{className:`inline`,children:[`Why White Gravity`,` `]}),(0,v.jsx)(`br`,{}),(0,v.jsxs)(`span`,{className:`inline`,children:[`Stands Out`,` `]}),(0,v.jsx)(`span`,{className:`block sm:inline-block whitespace-nowrap min-h-[1.2em]`,children:(0,v.jsx)(y,{words:[`in Noida`],typingSpeed:100,deletingSpeed:50,pauseTime:2e3,textClass:`text-slate-900`,cursorClass:`bg-slate-900 shadow-none`})})]}),(0,v.jsx)(`p`,{className:`
                mx-auto
                mt-5
                max-w-2xl
                text-center
                text-sm
                leading-7
                text-slate-600

                sm:text-base
                md:text-lg

                lg:mx-0
                lg:text-left
              `,children:(0,v.jsx)(g,{mode:`words`,text:`White Gravity is your trusted partner in digital transformation. We combine high-end engineering, intelligent automation, and strategic digital marketing to build technology ecosystems that empower businesses to grow faster and smarter.`})}),(0,v.jsx)(`div`,{className:`
                mt-8

                grid
                grid-cols-2
                gap-3

                sm:gap-4

                lg:grid-cols-6
                lg:gap-4
                xl:gap-5
              `,children:p.map((e,t)=>(0,v.jsx)(`div`,{className:`
                    min-w-0
                    w-full

                    ${t===4?`
                          col-span-2
                          mx-auto
                          w-[calc(50%-6px)]

                          lg:col-span-2
                          lg:col-start-4
                          lg:w-full
                        `:t===3?`
                          lg:col-span-2
                          lg:col-start-2
                        `:`
                          lg:col-span-2
                        `}
                  `,children:(0,v.jsx)(x,{item:e,i:t})},e.title))})]}),(0,v.jsx)(`div`,{className:`
              relative
              z-10
              block
              w-full
              min-w-0
              mx-auto

              lg:col-span-5
              lg:mx-0
            `,children:(0,v.jsxs)(`div`,{className:`
                relative
                block
                w-full
                px-4
                pb-10
                pt-8

                sm:px-8
                sm:pb-12
                sm:pt-10

                lg:px-6
                lg:pb-10
                lg:pt-10
              `,children:[(0,v.jsx)(`div`,{className:`
                  pointer-events-none
                  absolute
                  inset-5
                  rounded-[2rem]
                  bg-gradient-to-tr
                  from-emerald-100
                  to-teal-50

                  sm:inset-6
                  sm:rounded-[2.5rem]
                `,style:{transform:`rotate(3deg) scale(1.02)`}}),(0,v.jsxs)(`div`,{className:`
                  group
                  relative
                  z-10
                  block
                  aspect-square
                  w-full
                  overflow-hidden
                  rounded-[1.5rem]
                  border-[5px]
                  border-white
                  bg-white
                  shadow-2xl

                  sm:aspect-[4/5]
                  sm:rounded-[2rem]
                  sm:border-[6px]

                  lg:aspect-[4/5]
                `,children:[(0,v.jsx)(`img`,{src:`/images/about-collaboration-new.jpg`,alt:`White Gravity Team`,loading:`eager`,className:`
                    absolute
                    inset-0
                    block
                    h-full
                    w-full
                    object-cover
                    object-center
                    transition-transform
                    duration-700

                    group-hover:scale-105
                  `}),(0,v.jsx)(`div`,{className:`
                    pointer-events-none
                    absolute
                    inset-0
                    bg-gradient-to-t
                    from-emerald-950/40
                    via-transparent
                    to-transparent
                  `})]}),(0,v.jsx)(u.div,{initial:{opacity:0,scale:.5,y:20},whileInView:{opacity:1,scale:1,y:0},viewport:{once:!0},transition:{duration:.5,delay:.7,type:`spring`,stiffness:100},className:`
                  absolute
                  bottom-1
                  left-1
                  z-20
                  rounded-2xl
                  bg-white
                  px-3
                  py-2.5
                  shadow-[0_15px_30px_-5px_rgba(0,0,0,0.12)]

                  sm:bottom-2
                  sm:left-2
                  sm:px-4
                  sm:py-3

                  md:px-5
                  md:py-4
                `,children:(0,v.jsxs)(u.div,{animate:{y:[0,-6,0]},transition:{repeat:1/0,duration:4,ease:`easeInOut`},className:`
                    flex
                    items-center
                    gap-2.5

                    sm:gap-3
                  `,children:[(0,v.jsx)(`div`,{className:`
                      flex
                      h-9
                      w-9
                      flex-shrink-0
                      items-center
                      justify-center
                      rounded-full
                      bg-emerald-100

                      sm:h-11
                      sm:w-11
                    `,children:(0,v.jsx)(`span`,{className:`text-lg sm:text-xl`,children:`🏆`})}),(0,v.jsxs)(`div`,{children:[(0,v.jsx)(`div`,{className:`
                        text-lg
                        font-extrabold
                        leading-none
                        text-slate-900

                        sm:text-xl
                        md:text-2xl
                      `,children:`98%`}),(0,v.jsx)(`div`,{className:`
                        mt-1
                        whitespace-nowrap
                        text-[7px]
                        font-bold
                        uppercase
                        tracking-wider
                        text-slate-500

                        sm:text-[9px]
                        md:text-[10px]
                      `,children:`Client Satisfaction`})]})]})}),(0,v.jsx)(u.div,{initial:{opacity:0,scale:.5,y:-20},whileInView:{opacity:1,scale:1,y:0},viewport:{once:!0},transition:{duration:.5,delay:.9,type:`spring`,stiffness:100},className:`
                  absolute
                  right-1
                  top-1
                  z-20
                  rounded-2xl
                  bg-white
                  px-3
                  py-2.5
                  shadow-[0_15px_30px_-5px_rgba(0,0,0,0.12)]

                  sm:right-2
                  sm:top-2
                  sm:px-4
                  sm:py-3

                  md:px-5
                  md:py-4
                `,children:(0,v.jsxs)(u.div,{animate:{y:[0,6,0]},transition:{repeat:1/0,duration:5,ease:`easeInOut`,delay:1},className:`
                    flex
                    items-center
                    gap-2.5

                    sm:gap-3
                  `,children:[(0,v.jsx)(`div`,{className:`
                      flex
                      h-9
                      w-9
                      flex-shrink-0
                      items-center
                      justify-center
                      rounded-full
                      bg-emerald-100

                      sm:h-11
                      sm:w-11
                    `,children:(0,v.jsx)(`span`,{className:`
                        text-sm
                        font-bold
                        text-emerald-600

                        sm:text-lg
                      `,children:`5+`})}),(0,v.jsxs)(`div`,{children:[(0,v.jsx)(`div`,{className:`
                        whitespace-nowrap
                        text-sm
                        font-extrabold
                        leading-none
                        text-slate-900

                        sm:text-lg
                        md:text-xl
                      `,children:`Years Pro`}),(0,v.jsx)(`div`,{className:`
                        mt-1
                        whitespace-nowrap
                        text-[7px]
                        font-bold
                        uppercase
                        tracking-wider
                        text-slate-500

                        sm:text-[9px]
                        md:text-[10px]
                      `,children:`Experience`})]})]})})]})})]})})]})}function C({isMarquee:e=!1}){return(0,v.jsx)(`section`,{className:`py-10 sm:py-12 md:py-16 lg:py-20 bg-slate-50 relative overflow-hidden`,children:(0,v.jsxs)(`div`,{className:`container-x relative z-10 px-4 sm:px-6 lg:px-8`,children:[(0,v.jsx)(`div`,{className:`text-center max-w-3xl mx-auto mb-8 flex flex-col items-center`,children:(0,v.jsxs)(u.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.3},className:`flex flex-col items-center`,children:[(0,v.jsx)(h,{icon:n,children:`Tech Stack`}),(0,v.jsxs)(`h2`,{className:`mt-4 text-2xl sm:text-3xl md:text-5xl font-extrabold text-slate-900 leading-tight`,children:[(0,v.jsx)(g,{text:`Powered by `}),(0,v.jsx)(`span`,{className:`text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-400`,children:(0,v.jsx)(g,{text:`Enterprise Tech`})})]}),(0,v.jsx)(`p`,{className:`mt-4 text-slate-600 text-base leading-relaxed max-w-2xl`,children:`Modern, scalable, and secure technology stacks engineered for performance and growth.`})]})}),e?(0,v.jsxs)(`div`,{className:`relative w-full overflow-hidden mb-12 py-6`,children:[(0,v.jsx)(`div`,{className:`absolute left-0 top-0 bottom-0 w-16 md:w-24 bg-gradient-to-r from-slate-50 to-transparent z-10 pointer-events-none`}),(0,v.jsx)(`div`,{className:`absolute right-0 top-0 bottom-0 w-16 md:w-24 bg-gradient-to-l from-slate-50 to-transparent z-10 pointer-events-none`}),(0,v.jsx)(`div`,{className:`mb-6 overflow-hidden`,children:(0,v.jsx)(`div`,{className:`flex gap-4 w-max animate-marquee-slow`,children:[...[,,,]].flatMap(()=>[{name:`React`,icon:`react`},{name:`PHP / Laravel`,icon:`laravel`},{name:`WordPress`,icon:`wordpress`},{name:`Shopify`,icon:`shopify`},{name:`Node.js`,icon:`nodedotjs`},{name:`Next.js`,icon:`nextdotjs`},{name:`Microsoft .NET`,icon:`dotnet`},{name:`WooCommerce`,icon:`woocommerce`}]).map((e,t)=>(0,v.jsxs)(u.div,{animate:{y:[0,-8,0]},transition:{repeat:1/0,duration:3.5,ease:`easeInOut`,delay:t%8*.22},whileHover:{scale:1.08,y:-12,transition:{duration:.2}},className:`group bg-white rounded-full px-6 py-3.5 border border-slate-200/80 shadow-sm hover:shadow-[0_10px_25px_-4px_rgba(16,185,129,0.25)] hover:border-emerald-400 transition-all duration-300 cursor-default flex items-center gap-3 shrink-0`,children:[(0,v.jsx)(`div`,{className:`w-7 h-7 rounded-full bg-slate-50 flex items-center justify-center p-1 group-hover:bg-[#e6f7f2] transition-colors overflow-hidden`,children:(0,v.jsx)(`img`,{src:`/images/tech/${e.icon}.svg`,alt:e.name,className:`w-full h-full object-contain group-hover:scale-110 transition-transform duration-300`})}),(0,v.jsx)(`span`,{className:`text-sm md:text-base font-bold text-slate-800 group-hover:text-[#009B6C] transition-colors whitespace-nowrap`,children:e.name})]},`r1-${t}`))})}),(0,v.jsx)(`div`,{className:`overflow-hidden`,children:(0,v.jsx)(`div`,{className:`flex gap-4 w-max animate-marquee-reverse-slow`,children:[...[,,,]].flatMap(()=>[{name:`Flutter`,icon:`flutter`},{name:`React Native`,icon:`react`},{name:`AWS`,icon:`aws`},{name:`Google Cloud`,icon:`googlecloud`},{name:`MySQL`,icon:`mysql`},{name:`MongoDB`,icon:`mongodb`},{name:`Zoho CRM`,icon:`zoho`},{name:`Shopify`,icon:`shopify`}]).map((e,t)=>(0,v.jsxs)(u.div,{animate:{y:[0,-8,0]},transition:{repeat:1/0,duration:3.5,ease:`easeInOut`,delay:t%8*.22},whileHover:{scale:1.08,y:-12,transition:{duration:.2}},className:`group bg-white rounded-full px-6 py-3.5 border border-slate-200/80 shadow-sm hover:shadow-[0_10px_25px_-4px_rgba(16,185,129,0.25)] hover:border-emerald-400 transition-all duration-300 cursor-default flex items-center gap-3 shrink-0`,children:[(0,v.jsx)(`div`,{className:`w-7 h-7 rounded-full bg-slate-50 flex items-center justify-center p-1 group-hover:bg-[#e6f7f2] transition-colors overflow-hidden`,children:(0,v.jsx)(`img`,{src:`/images/tech/${e.icon}.svg`,alt:e.name,className:`w-full h-full object-contain group-hover:scale-110 transition-transform duration-300`})}),(0,v.jsx)(`span`,{className:`text-sm md:text-base font-bold text-slate-800 group-hover:text-[#009B6C] transition-colors whitespace-nowrap`,children:e.name})]},`r2-${t}`))})})]}):(0,v.jsx)(`div`,{className:`flex flex-wrap items-center justify-center gap-3 md:gap-4 mb-12 max-w-5xl mx-auto`,children:[{name:`React`,icon:`react`},{name:`PHP / Laravel`,icon:`laravel`},{name:`WordPress`,icon:`wordpress`},{name:`Shopify`,icon:`shopify`},{name:`Node.js`,icon:`nodedotjs`},{name:`Next.js`,icon:`nextdotjs`},{name:`Microsoft .NET`,icon:`dotnet`},{name:`WooCommerce`,icon:`woocommerce`},{name:`Flutter`,icon:`flutter`},{name:`React Native`,icon:`react`},{name:`AWS`,icon:`aws`},{name:`Google Cloud`,icon:`googlecloud`},{name:`MySQL`,icon:`mysql`},{name:`MongoDB`,icon:`mongodb`},{name:`Zoho CRM`,icon:`zoho`}].map((e,t)=>(0,v.jsxs)(u.div,{initial:{opacity:0,y:20,scale:.9},whileInView:{opacity:1,y:0,scale:1},viewport:{once:!0},transition:{duration:.4,delay:t*.05,ease:[.22,1,.36,1]},whileHover:{scale:1.08,y:-4},className:`group bg-white rounded-full px-6 py-3.5 border border-slate-200/80 shadow-[0_4px_15px_-4px_rgba(0,0,0,0.05)] hover:shadow-[0_10px_25px_-4px_rgba(16,185,129,0.2)] hover:border-emerald-400 transition-all duration-300 cursor-default flex items-center gap-3`,children:[(0,v.jsx)(`div`,{className:`w-7 h-7 rounded-full bg-slate-50 flex items-center justify-center p-1 group-hover:bg-[#e6f7f2] transition-colors overflow-hidden`,children:(0,v.jsx)(`img`,{src:`/images/tech/${e.icon}.svg`,alt:e.name,className:`w-full h-full object-contain transition-transform duration-300 group-hover:scale-110`})}),(0,v.jsx)(`span`,{className:`text-sm md:text-base font-bold text-slate-800 group-hover:text-[#009B6C] transition-colors`,children:e.name})]},e.name))}),(0,v.jsxs)(`div`,{className:`pt-14 md:pt-16 border-t border-slate-200`,children:[(0,v.jsx)(`div`,{className:`text-center max-w-3xl mx-auto mb-10 md:mb-12 flex flex-col items-center`,children:(0,v.jsxs)(u.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.3},className:`flex flex-col items-center`,children:[(0,v.jsx)(`span`,{className:`inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-100/80 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-3 shadow-sm`,children:`Strategic Alliance`}),(0,v.jsxs)(`h3`,{className:`text-3xl md:text-5xl font-extrabold text-slate-900`,children:[`Official `,(0,v.jsx)(`span`,{className:`text-emerald-600`,children:`Technology Partners`})]}),(0,v.jsx)(`p`,{className:`mt-4 text-slate-600 text-base md:text-lg max-w-2xl`,children:`Certified partnerships with world-class platforms to deliver enterprise-grade execution.`})]})}),(0,v.jsx)(`div`,{className:`flex flex-col gap-12 md:gap-16 mt-8`,children:Array.from(new Set(m.map(e=>e.category))).filter(Boolean).map(e=>(0,v.jsxs)(`div`,{className:`w-full`,children:[(0,v.jsx)(`h4`,{className:`text-xs md:text-sm font-extrabold text-slate-400 uppercase tracking-[0.2em] mb-8 text-center flex items-center justify-center gap-6 before:h-[1px] before:bg-gradient-to-r before:from-transparent before:to-slate-300 before:flex-1 after:h-[1px] after:bg-gradient-to-l after:from-transparent after:to-slate-300 after:flex-1 max-w-4xl mx-auto px-4`,children:e}),(0,v.jsx)(`div`,{className:`flex flex-wrap md:flex-nowrap justify-center items-center gap-3 sm:gap-4 md:gap-5 max-w-6xl mx-auto px-4 py-6 overflow-x-auto`,children:m.filter(t=>t.category===e).map((e,t)=>(0,v.jsxs)(u.div,{initial:{opacity:0,y:24,scale:.92},whileInView:{opacity:1,y:0,scale:1},viewport:{once:!0},transition:{duration:.4,delay:t*.06,ease:[.22,1,.36,1]},whileHover:{y:-6,scale:1.05,transition:{duration:.25}},className:`group relative bg-white rounded-2xl p-4 sm:p-5 h-34 sm:h-38 md:h-40 w-[135px] sm:w-[155px] md:w-[175px] lg:w-[185px] flex flex-col items-center justify-center border-2 border-slate-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.06)] hover:shadow-[0_20px_40px_-10px_rgba(16,185,129,0.25)] hover:border-emerald-400 hover:z-20 transition-all duration-300 cursor-default overflow-hidden shrink-0`,children:[(0,v.jsx)(`div`,{className:`absolute inset-0 bg-gradient-to-br from-emerald-50/0 to-emerald-100/0 group-hover:from-emerald-50/70 group-hover:to-transparent transition-all duration-500 rounded-2xl`}),(0,v.jsx)(`div`,{className:`h-12 md:h-14 w-full flex items-center justify-center relative z-10 mb-2`,children:(0,v.jsx)(`img`,{src:e.img,alt:e.name,className:`max-h-10 md:max-h-12 max-w-[110px] md:max-w-[135px] w-auto object-contain transition-all duration-500 group-hover:scale-105 filter drop-shadow-sm`})}),(0,v.jsx)(`div`,{className:`text-center relative z-10`,children:(0,v.jsx)(`span`,{className:`text-xs sm:text-sm font-extrabold text-slate-800 group-hover:text-emerald-600 transition-colors block leading-tight`,children:e.name})})]},e.name))})]},e))})]})]})})}export{S as n,y as r,C as t};